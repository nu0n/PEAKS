using UnityEngine;
using UnityEngine.Animations.Rigging;

/// <summary>
/// Drives one hand's IK target toward its grip point.
/// Requires: Animation Rigging package, TwoBoneIKConstraint on the Rig.
/// </summary>
public class HandController : MonoBehaviour
{
    [Header("Which hand")]
    public bool isLeftHand = true;

    [Header("IK References")]
    [Tooltip("The IK target transform that TwoBoneIKConstraint follows.")]
    public Transform ikTarget;

    [Tooltip("The IK hint (elbow) transform.")]
    public Transform ikHint;

    [Header("Settings")]
    public float gripSmoothTime = 0.08f;   // how fast the hand snaps to grip
    public float releaseSmoothTime = 0.15f; // how fast the hand returns to idle pose
    public float reachSmoothTime = 0.12f;  // speed when reaching for a preview

    [Header("Idle pose offsets (local space from body)")]
    public Vector3 idlePositionOffset = new Vector3(-0.5f, -0.3f, 0.4f);
    public Vector3 idleHintOffset     = new Vector3(-0.8f, -0.5f, 0f);
    public float idleSwayAmount       = 0.05f;
    public float idleSwaySpeed        = 1.5f;

    private Transform _bodyTransform;
    private GripData  _grip = GripData.Empty;
    private GripData  _previewGrip = GripData.Empty;
    private bool      _gripping = false;
    private float     _swayTimer;

    // Smoothing buffers
    private Vector3 _posVelocity;
    private Vector3 _hintVelocity;

    public void Initialize(Transform bodyRoot)
    {
        _bodyTransform = bodyRoot;
        _swayTimer = isLeftHand ? 0 : 100f; // Offset left and right hands
    }

    /// <summary>Set an active grip. Hand lerps to the grip position.</summary>
    public void SetGrip(GripData grip)
    {
        _grip     = grip;
        _gripping = grip.isActive;
    }

    /// <summary>Set a preview grip for 'reaching' visual.</summary>
    public void SetPreviewGrip(GripData preview)
    {
        _previewGrip = preview;
    }

    /// <summary>Clear the grip. Hand returns to idle.</summary>
    public void ClearGrip()
    {
        _grip     = GripData.Empty;
        _gripping = false;
    }

    public bool IsGripping => _gripping;

    private void Update()
    {
        if (_gripping && _grip.isActive)
        {
            ApplyGrip(_grip, gripSmoothTime);
        }
        else if (_previewGrip.isActive)
        {
            // Reach toward the preview point
            ApplyGrip(_previewGrip, reachSmoothTime);
        }
        else if (_bodyTransform != null)
        {
            // Return to idle pose with subtle breathing sway
            _swayTimer += Time.deltaTime * idleSwaySpeed;
            float swayX = (Mathf.PerlinNoise(_swayTimer, 0) - 0.5f) * idleSwayAmount;
            float swayY = (Mathf.PerlinNoise(0, _swayTimer) - 0.5f) * idleSwayAmount;
            float swayZ = (Mathf.PerlinNoise(_swayTimer, _swayTimer) - 0.5f) * idleSwayAmount;
            
            Vector3 swayedOffset = idlePositionOffset + new Vector3(swayX, swayY, swayZ);
            Vector3 idleWorld = _bodyTransform.TransformPoint(swayedOffset);
            
            ikTarget.position = Vector3.SmoothDamp(
                ikTarget.position,
                idleWorld,
                ref _posVelocity,
                releaseSmoothTime
            );
            ikTarget.rotation = Quaternion.Slerp(
                ikTarget.rotation,
                _bodyTransform.rotation,
                Time.deltaTime * (1f / releaseSmoothTime)
            );
        }
    }

    private void ApplyGrip(GripData targetGrip, float smoothTime)
    {
        // Move IK target toward grip world position
        ikTarget.position = Vector3.SmoothDamp(
            ikTarget.position,
            targetGrip.CurrentWorldPosition,
            ref _posVelocity,
            smoothTime
        );

        // Orient IK target to surface normal
        Quaternion targetRot = Quaternion.LookRotation(-targetGrip.surfaceNormal, Vector3.up);
        ikTarget.rotation = Quaternion.Slerp(
            ikTarget.rotation,
            targetRot,
            Time.deltaTime * (1f / smoothTime)
        );

        // Push elbow hint outward
        Vector3 elbowDir = isLeftHand ? -_bodyTransform.right : _bodyTransform.right;
        Vector3 targetHint = targetGrip.CurrentWorldPosition + elbowDir * 0.4f + Vector3.down * 0.2f;
        ikHint.position = Vector3.SmoothDamp(
            ikHint.position,
            targetHint,
            ref _hintVelocity,
            smoothTime
        );
    }
}
