using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Central controller. Ties input -> grip detection -> body physics -> hand IK.
/// Implements 'Hold-to-Grip' with Trigger-Modifiers for dual-stick control.
/// </summary>
public class ClimbStateManager : MonoBehaviour
{
    public enum ClimbState { Idle, LeftGrip, RightGrip, BothGrip, Releasing }

    [Header("Component References")]
    public GripDetector     gripDetector;
    public HandController   leftHand;
    public HandController   rightHand;
    public ClimbBodyPhysics bodyPhysics;
    public Camera           playerCamera;
    public GripPreviewManager previewManager;

    [Header("Input Actions")]
    public InputActionReference gripLeftAction;  // L2 (Left Trigger)
    public InputActionReference gripRightAction; // R2 (Right Trigger)
    public InputActionReference moveAction;      // Left Stick
    public InputActionReference lookAction;      // Right Stick
    public InputActionReference jumpAction;      // Button South (A)

    [Header("Hand Reach Settings")]
    public float handReachRadius = 240f; // Screen pixels reach from center (adjusted for practicality)

    private ClimbState _state = ClimbState.Idle;
    private GripData   _leftGrip  = GripData.Empty;
    private GripData   _rightGrip = GripData.Empty;

    private float _leftHoldTime, _rightHoldTime;

    // Exposed for UI reticles
    public Vector2 LeftScreenPos { get; private set; }
    public Vector2 RightScreenPos { get; private set; }

    // Aiming State Properties
    public bool IsLeftHandAiming => GetActionPressed(gripLeftAction);
    public bool IsRightHandAiming => GetActionPressed(gripRightAction);

    /// <summary>
    /// Left Stick controls camera ONLY if Left Trigger is held AND Right Hand is gripping.
    /// </summary>
    public bool IsLeftStickCameraActive => IsLeftHandAiming && _rightGrip.isActive;

    private bool GetActionPressed(InputActionReference actionRef)
    {
        if (actionRef == null || actionRef.action == null) return false;
        // Use a slightly lower threshold for holding than for starting if we wanted hysteresis,
        // but for now just ensure it's robust.
        return actionRef.action.IsPressed();
    }

    private void Start()
    {
        if (leftHand != null) leftHand.Initialize(transform);
        if (rightHand != null) rightHand.Initialize(transform);
    }

    private void OnEnable()
    {
        EnableAction(gripLeftAction);
        EnableAction(gripRightAction);
        EnableAction(moveAction);
        EnableAction(lookAction);
        if (jumpAction != null)
        {
            jumpAction.action.Enable();
            jumpAction.action.started += OnJump;
        }
    }

    private void OnDisable()
    {
        DisableAction(gripLeftAction);
        DisableAction(gripRightAction);
        DisableAction(moveAction);
        DisableAction(lookAction);
        if (jumpAction != null)
        {
            jumpAction.action.started -= OnJump;
            jumpAction.action.Disable();
        }
    }

    private void EnableAction(InputActionReference reference)
    {
        if (reference != null && reference.action != null) reference.action.Enable();
    }

    private void DisableAction(InputActionReference reference)
    {
        if (reference != null && reference.action != null) reference.action.Disable();
    }

    private void Update()
    {
        HandleHandInput();
        HandleBodyInput();
        CheckCrumblingGrips();

        // Sync physics state
        if (bodyPhysics != null)
        {
            Rigidbody rb = GetComponent<Rigidbody>();
            Vector3 currentVel = rb != null ? rb.linearVelocity : Vector3.zero;
            bodyPhysics.SetGrips(_leftGrip, _rightGrip, currentVel);
        }
        UpdateState();
    }

    private void HandleHandInput()
    {
        Vector2 screenCenter = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);

        // --- LEFT HAND ---
        bool leftAim = IsLeftHandAiming;
        Vector2 leftStick = (moveAction != null && moveAction.action != null) ? moveAction.action.ReadValue<Vector2>() : Vector2.zero;
        
        // If not gripped, reticle follows stick. If gripped, it stays on the grip point.
        if (!_leftGrip.isActive)
        {
            // If the left stick is being used for camera rotation, keep the reticle at center
            Vector2 stickOffset = IsLeftStickCameraActive ? Vector2.zero : leftStick;
            LeftScreenPos = screenCenter + stickOffset * handReachRadius;
        }
        else if (playerCamera != null)
        {
            LeftScreenPos = playerCamera.WorldToScreenPoint(_leftGrip.CurrentWorldPosition);
        }
        
        if (previewManager != null)
        {
            previewManager.SetLeftPoint(LeftScreenPos, leftAim || _leftGrip.isActive);
            
            if (leftAim && !_leftGrip.isActive)
            {
                if (previewManager.LeftPreview.isActive)
                {
                    _leftGrip = previewManager.LeftPreview;
                }
            }
            else if (!leftAim)
            {
                _leftGrip = GripData.Empty;
            }
            
            if (leftHand != null)
            {
                leftHand.SetGrip(_leftGrip);
                leftHand.SetPreviewGrip(previewManager.LeftPreview);
            }
        }

        // --- RIGHT HAND ---
        bool rightAim = IsRightHandAiming;
        Vector2 rightStick = (lookAction != null && lookAction.action != null) ? lookAction.action.ReadValue<Vector2>() : Vector2.zero;
        
        if (!_rightGrip.isActive)
        {
            RightScreenPos = screenCenter + rightStick * handReachRadius;
        }
        else if (playerCamera != null)
        {
            RightScreenPos = playerCamera.WorldToScreenPoint(_rightGrip.CurrentWorldPosition);
        }

        if (previewManager != null)
        {
            previewManager.SetRightPoint(RightScreenPos, rightAim || _rightGrip.isActive);

            if (rightAim && !_rightGrip.isActive)
            {
                if (previewManager.RightPreview.isActive)
                {
                    _rightGrip = previewManager.RightPreview;
                }
            }
            else if (!rightAim)
            {
                _rightGrip = GripData.Empty;
            }

            if (rightHand != null)
            {
                rightHand.SetGrip(_rightGrip);
                rightHand.SetPreviewGrip(previewManager.RightPreview);
            }
        }
    }

    private void HandleBodyInput()
    {
        // Allow swinging/moving at all times if physics is present
        if (moveAction != null && moveAction.action != null && bodyPhysics != null)
        {
            Vector2 move = moveAction.action.ReadValue<Vector2>();
            bodyPhysics.ApplySwing(new Vector3(move.x, move.y, 0f), playerCamera);
        }
    }

    private void OnJump(InputAction.CallbackContext ctx)
    {
        if (_state != ClimbState.Idle && bodyPhysics != null)
        {
            bodyPhysics.Jump(playerCamera);
            _leftGrip = GripData.Empty;
            _rightGrip = GripData.Empty;
            leftHand.ClearGrip();
            rightHand.ClearGrip();
            UpdateState();
        }
    }

    private void CheckCrumblingGrips()
    {
        CheckCrumblingGrip(ref _leftGrip, leftHand, ref _leftHoldTime);
        CheckCrumblingGrip(ref _rightGrip, rightHand, ref _rightHoldTime);
    }

    private void CheckCrumblingGrip(ref GripData grip, HandController hand, ref float holdTime)
    {
        if (!grip.isActive)
        {
            holdTime = 0f;
            return;
        }

        ClimbSurface surface = grip.attachedTo?.GetComponent<ClimbSurface>();
        if (surface == null || !surface.isCrumbling) return;

        holdTime += Time.deltaTime;
        if (holdTime >= surface.holdDuration)
        {
            grip = GripData.Empty;
            hand.ClearGrip();
            UpdateState();
        }
    }

    private void UpdateState()
    {
        bool l = _leftGrip.isActive;
        bool r = _rightGrip.isActive;

        if (l && r)       _state = ClimbState.BothGrip;
        else if (l)       _state = ClimbState.LeftGrip;
        else if (r)       _state = ClimbState.RightGrip;
        else              _state = ClimbState.Idle;
    }

    public ClimbState CurrentState => _state;
}
