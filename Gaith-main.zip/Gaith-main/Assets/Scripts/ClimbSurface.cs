using UnityEngine;

[RequireComponent(typeof(Collider))]
public class ClimbSurface : MonoBehaviour
{
    [Tooltip("How grippy the surface is. 1 = normal, 0 = slips off immediately.")]
    [Range(0f, 1f)]
    public float gripStrength = 1f;

    [Tooltip("If true, player can only hold for holdDuration seconds.")]
    public bool isCrumbling = false;
    public float holdDuration = 3f;

    private void Reset()
    {
        gameObject.layer = LayerMask.NameToLayer("Climbable");
    }
}
