using UnityEngine;

/// <summary>
/// Drives the Rigidbody toward the average grip anchor point using Kinematic movement.
/// This eliminates repulsion from the wall and provides absolute stability.
/// </summary>
[RequireComponent(typeof(Rigidbody))]
public class ClimbBodyPhysics : MonoBehaviour
{
    [Header("Climb forces")]
    public float pullSmoothTime    = 0.1f;     // How fast body moves to anchor
    public float rotationTorque    = 10f;      // Rotation speed
    public float swingAcceleration = 15f;      // Acceleration speed when swinging
    public float swingFriction     = 4f;       // Damping for swing momentum
    public float jumpImpulse       = 22f;
    public float wallJumpKickForce = 5f;

    [Header("Body offset below grips")]
public float bodyHangOffset    = 0.8f;
    public float bodyDepthOffset   = 0.55f;    // Adjusted to match capsule radius + buffer

    [Header("Collision Settings")]
    public LayerMask collisionMask = -1;       // Layers to collide with during kinematic climb

    private Rigidbody _rb;
    private CapsuleCollider _capsule;
    private GripData  _leftGrip  = GripData.Empty;
    private GripData  _rightGrip = GripData.Empty;
private bool      _isClimbing = false;
    private Vector3   _swingInput; // Buffer for swing input

    // Smoothing buffers
    private Vector3 _moveVelocity;

    // Velocity Tracking for Momentum Release
    private Vector3[] _velocityBuffer = new Vector3[8]; // Track last 8 frames
    private int       _bufferIndex = 0;
    private Vector3   _lastPosition;
    private Vector3   _swingVelocity; // Persistent swing velocity when climbing
    private Vector3   _lastWallNormal = Vector3.back;

    // Cached state
private float   _lastLogTime = -100f;
    private bool    _wasKinematic;

    private void Awake()
    {
        _rb = GetComponent<Rigidbody>();
        _capsule = GetComponent<CapsuleCollider>();
        
        _rb.interpolation = RigidbodyInterpolation.Interpolate;
        _rb.collisionDetectionMode = CollisionDetectionMode.Continuous;
        _lastPosition = _rb.position;

        // Auto-adjust depth offset if it's too tight for the capsule
        if (_capsule != null)
        {
            float minSafeOffset = _capsule.radius + 0.05f;
            if (bodyDepthOffset < minSafeOffset)
            {
                bodyDepthOffset = minSafeOffset;
                Debug.Log($"[ClimbBodyPhysics] Auto-adjusted bodyDepthOffset to {bodyDepthOffset} to match CapsuleCollider radius.");
            }
        }
    }

    public void SetGrips(GripData left, GripData right, Vector3 initialVelocity = default)
    {
        bool wasClimbing = _isClimbing;
        _leftGrip  = left;
        _rightGrip = right;
        bool currentlyGrip = left.isActive || right.isActive;

        if (!wasClimbing && currentlyGrip)
        {
            _isClimbing = true;
            _wasKinematic = _rb.isKinematic;
            _rb.isKinematic = true;
            
            // Handover momentum: Use initial velocity if provided, otherwise zero.
            _swingVelocity = initialVelocity;
            
            _lastPosition = _rb.position;
            _moveVelocity = Vector3.zero; // Reset smoothdamp buffer
            
            // Clear buffer
            for (int i = 0; i < _velocityBuffer.Length; i++) _velocityBuffer[i] = initialVelocity;
            Debug.Log($"[ClimbBodyPhysics] Started Kinematic Climbing with initial velocity: {initialVelocity.magnitude:F2}");
        }
        else if (wasClimbing && !currentlyGrip)
        {
            _isClimbing = false;
            ReleaseMomentum();
            Debug.Log("[ClimbBodyPhysics] Stopped Kinematic Climbing (Released Momentum).");
            _lastLogTime = -100f; 
        }
    }

    private void ReleaseMomentum()
    {
        _rb.isKinematic = _wasKinematic;
        _rb.useGravity = true;

        // Calculate average velocity from buffer
        Vector3 avgVel = Vector3.zero;
        foreach (var v in _velocityBuffer) avgVel += v;
        avgVel /= _velocityBuffer.Length;

        // Apply to Rigidbody
        _rb.linearVelocity = avgVel;
    }

    public void ApplySwing(Vector3 moveInput, Camera cam)
    {
        if (!_isClimbing) return;
        _swingInput = moveInput;
    }

    public void Jump(Camera cam = null)
    {
        _leftGrip  = GripData.Empty;
        _rightGrip = GripData.Empty;
        _isClimbing = false;
        
        _rb.isKinematic = _wasKinematic;
        _rb.useGravity = true;

        // Calculate tracked momentum
        Vector3 avgVel = Vector3.zero;
        foreach (var v in _velocityBuffer) avgVel += v;
        avgVel /= _velocityBuffer.Length;

        // Directional Impulse
        Vector3 jumpDir = Vector3.up;
        if (cam != null)
        {
            // Blend camera forward and world up for a natural "launch"
            jumpDir = (cam.transform.forward * 0.4f + Vector3.up * 0.6f).normalized;
        }

        // Apply impulse additive to existing momentum, including a "kick" away from the wall
        Vector3 kick = _lastWallNormal * wallJumpKickForce;
        _rb.linearVelocity = avgVel + jumpDir * jumpImpulse + kick;
    }

    private void FixedUpdate()
    {
        if (!_isClimbing) 
        {
            _lastPosition = _rb.position;
            return;
        }

        // --- Handle Swing Buffer ---
        if (Camera.main != null)
        {
            Vector3 camRight = Camera.main.transform.right;
            Vector3 up = Vector3.up;
            Vector3 accelDir = (camRight * _swingInput.x + up * _swingInput.y);

            if (accelDir.sqrMagnitude > 0.01f)
            {
                _swingVelocity += accelDir * swingAcceleration * Time.fixedDeltaTime;
            }
        }
        _swingVelocity -= _swingVelocity * swingFriction * Time.fixedDeltaTime;

        // --- Kinematic Movement ---
        Vector3 anchor = Vector3.zero;
        int count = 0;
        Vector3 wallNormal = Vector3.zero;

        if (_leftGrip.isActive)
        {
            anchor     += _leftGrip.CurrentWorldPosition;
            wallNormal += _leftGrip.surfaceNormal;
            count++;
        }
        if (_rightGrip.isActive)
        {
            anchor     += _rightGrip.CurrentWorldPosition;
            wallNormal += _rightGrip.surfaceNormal;
            count++;
        }

        if (count > 0)
        {
            anchor /= count;
            wallNormal = (wallNormal / count).normalized;
            _lastWallNormal = wallNormal;

            Vector3 depthDirection = new Vector3(wallNormal.x, 0, wallNormal.z).normalized;
if (depthDirection == Vector3.zero) 
            {
                Vector3 toBody = _rb.position - anchor;
                depthDirection = new Vector3(toBody.x, 0, toBody.z).normalized;
                if (depthDirection == Vector3.zero) depthDirection = -transform.forward; 
            }

            Vector3 targetPos = anchor - Vector3.up * bodyHangOffset + depthDirection * bodyDepthOffset;
            
            // Apply swing and anchor pull using SmoothDamp
            Vector3 nextPos = Vector3.SmoothDamp(_rb.position, targetPos, ref _moveVelocity, pullSmoothTime);
            nextPos += _swingVelocity * Time.fixedDeltaTime;
            
            // --- Kinematic Collision Check ---
            // Prevent the body from being forced into geometry by the pull/swing forces
            if (_capsule != null)
            {
                Vector3 moveDir = nextPos - _rb.position;
                float moveDist = moveDir.magnitude;
                
                if (moveDist > 0.001f)
                {
                    // Calculate capsule ends for SweepTest or SphereCast
                    float centerToBottom = (_capsule.height * 0.5f) - _capsule.radius;
                    Vector3 point1 = _rb.position + _capsule.center + Vector3.up * centerToBottom;
                    Vector3 point2 = _rb.position + _capsule.center - Vector3.up * centerToBottom;

                    // We use CapsuleCast to check the path
                    if (Physics.CapsuleCast(point1, point2, _capsule.radius * 0.95f, moveDir.normalized, out RaycastHit hit, moveDist, collisionMask, QueryTriggerInteraction.Ignore))
                    {
                        // Collision detected! Clamp movement to the surface
                        nextPos = _rb.position + moveDir.normalized * (hit.distance - 0.01f);
                        
                        // Damp swing velocity in the direction of the hit
                        float dot = Vector3.Dot(_swingVelocity, hit.normal);
                        if (dot < 0)
                        {
                            _swingVelocity -= hit.normal * dot; // Remove velocity toward the wall
                        }
                    }
                }
            }

            _rb.MovePosition(nextPos);

            Vector3 horizontalNormal = new Vector3(wallNormal.x, 0, wallNormal.z).normalized;
            if (horizontalNormal != Vector3.zero)
            {
                Quaternion targetRot = Quaternion.LookRotation(-horizontalNormal, Vector3.up);
                _rb.MoveRotation(Quaternion.Slerp(_rb.rotation, targetRot, Time.fixedDeltaTime * rotationTorque));
            }
        }

        // --- Velocity Tracking ---
        Vector3 currentVel = (_rb.position - _lastPosition) / Time.fixedDeltaTime;
        _velocityBuffer[_bufferIndex] = currentVel;
        _bufferIndex = (_bufferIndex + 1) % _velocityBuffer.Length;
        _lastPosition = _rb.position;

        if (Time.time - _lastLogTime > 15f)
        {
            Debug.Log($"[ClimbPhysics] Kinematic Pos: {_rb.position:F2}, Anchor: {anchor:F2}, Est. Vel: {currentVel.magnitude:F2}");
            _lastLogTime = Time.time;
        }
    }
}