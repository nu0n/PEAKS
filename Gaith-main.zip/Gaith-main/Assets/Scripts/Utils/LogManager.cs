using UnityEngine;

public static class LogManager
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    private static void Initialize()
    {
        // Replace the default debug log handler with our throttled one, but don't double wrap
        if (Debug.unityLogger.logHandler is ThrottledLogHandler) return;

        Debug.unityLogger.logHandler = new ThrottledLogHandler(Debug.unityLogger.logHandler);
        
        Debug.Log("Throttled Logging System Initialized (15s repetitions).");
    }
}
