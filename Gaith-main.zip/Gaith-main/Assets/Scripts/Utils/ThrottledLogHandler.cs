using System;
using System.Collections.Generic;
using UnityEngine;

public class ThrottledLogHandler : ILogHandler
{
    private readonly ILogHandler _defaultLogHandler;
    private readonly Dictionary<string, (int count, float firstLogTime)> _history = new Dictionary<string, (int, float)>();
    
    private const float WINDOW_SECONDS = 15f;
    private const int MAX_REPETITIONS = 1;

    public ThrottledLogHandler(ILogHandler defaultLogHandler)
    {
        _defaultLogHandler = defaultLogHandler;
    }

    public void LogFormat(LogType logType, UnityEngine.Object context, string format, params object[] args)
    {
        string message = string.Format(format, args);
        if (ShouldLog(message))
        {
            _defaultLogHandler.LogFormat(logType, context, format, args);
        }
    }

    public void LogException(Exception exception, UnityEngine.Object context)
    {
        string message = exception.ToString();
        if (ShouldLog(message))
        {
            _defaultLogHandler.LogException(exception, context);
        }
    }

    private bool ShouldLog(string key)
    {
        float currentTime = Time.realtimeSinceStartup;

        if (_history.TryGetValue(key, out var entry))
        {
            // If window expired, reset
            if (currentTime - entry.firstLogTime > WINDOW_SECONDS)
            {
                _history[key] = (1, currentTime);
                return true;
            }

            // Increment count
            entry.count++;
            _history[key] = entry;

            // Only log if count <= MAX_REPETITIONS
            return entry.count <= MAX_REPETITIONS;
        }

        // First time seeing this message
        _history[key] = (1, currentTime);
        return true;
    }
}
