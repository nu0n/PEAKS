using UnityEngine;
using UnityEngine.InputSystem;

/// <summary>
/// Manages visual 'Ghost Hands' that show where a grip will land.
/// Supports independent dual-stick control and contextual visibility.
/// </summary>
public class GripPreviewManager : MonoBehaviour
{
    [Header("References")]
    public GripDetector gripDetector;
    public Transform leftGhostHand;
    public Transform rightGhostHand;
    public Camera playerCamera;

    [Header("Settings")]
    public float lerpSpeed = 20f;

    private GripData _leftPreview = GripData.Empty;
    private GripData _rightPreview = GripData.Empty;

    public GripData LeftPreview => _leftPreview;
    public GripData RightPreview => _rightPreview;

    private Vector2 _leftScreenPoint;
    private Vector2 _rightScreenPoint;

    private bool _leftVisible = false;
    private bool _rightVisible = false;

    private void Start()
    {
        if (leftGhostHand != null) leftGhostHand.gameObject.SetActive(false);
        if (rightGhostHand != null) rightGhostHand.gameObject.SetActive(false);
        
        // Default to center
        _leftScreenPoint = _rightScreenPoint = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);
    }

    public void SetLeftPoint(Vector2 point, bool visible)
    {
        _leftScreenPoint = point;
        _leftVisible = visible;
    }

    public void SetRightPoint(Vector2 point, bool visible)
    {
        _rightScreenPoint = point;
        _rightVisible = visible;
    }

    private void Update()
    {
        if (gripDetector == null || playerCamera == null) return;

        // Independently update left/right previews
        UpdateHand(leftGhostHand, _leftScreenPoint, _leftVisible, ref _leftPreview);
        UpdateHand(rightGhostHand, _rightScreenPoint, _rightVisible, ref _rightPreview);
    }

    private void UpdateHand(Transform ghost, Vector2 screenPoint, bool visible, ref GripData store)
    {
        if (ghost == null) return;

        GripData currentGrip = gripDetector.TryGetGrip(screenPoint);

        // Show ghost only if requested visible AND a grip is found
        if (visible && currentGrip.isActive)
        {
            ghost.gameObject.SetActive(true);
            store = currentGrip;

            // Position ghost at hit point
            ghost.position = Vector3.Lerp(ghost.position, currentGrip.worldPosition, Time.deltaTime * lerpSpeed);
            
            // Orient ghost to surface normal
            Quaternion targetRot = Quaternion.LookRotation(-currentGrip.surfaceNormal, Vector3.up);
            ghost.rotation = Quaternion.Slerp(ghost.rotation, targetRot, Time.deltaTime * lerpSpeed);
        }
        else
        {
            ghost.gameObject.SetActive(false);
            store = GripData.Empty;
        }
    }
}
