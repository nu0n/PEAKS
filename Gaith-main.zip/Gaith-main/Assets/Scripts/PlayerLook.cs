using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerLook : MonoBehaviour
{
    [Header("Settings")]
    public float lookSensitivity = 1f;
    public float xRotationLimit = 85f;
    public float lookSmoothing = 15f;

    [Header("Bobbing Settings")]
    public float bobFrequency = 5f;
    public float bobHorizontalAmount = 0.05f;
    public float bobVerticalAmount = 0.1f;
    public float bobSmoothing = 8f;

    [Header("References")]
    public Transform cameraRoot;
    public InputActionReference lookAction;
    public InputActionReference moveAction;
    public ClimbStateManager climbStateManager;

    private float _xRotation = 0f; // Pitch
    private float _yRotation = 0f; // Yaw
    private float _smoothXRotation = 0f;
    private float _smoothYRotation = 0f;
    private float _bodyYaw = 0f;
    private float _smoothBodyYaw = 0f;
    
    private Rigidbody _rb;
    private float _bobTimer;
    private Vector3 _initialCameraPos;
    private Vector3 _currentBobOffset;
    private float _landingDipAmount;
    private bool _wasClimbing;

    private void Start()
    {
        _rb = GetComponent<Rigidbody>();
        
        // Initialize rotations from current transform state to avoid snaps
        _bodyYaw = transform.eulerAngles.y;
        _smoothBodyYaw = _bodyYaw;
        
        if (cameraRoot != null)
        {
            _initialCameraPos = cameraRoot.localPosition;
            _xRotation = cameraRoot.localEulerAngles.x;
            // Normalize pitch to -180, 180
            if (_xRotation > 180) _xRotation -= 360;
            _smoothXRotation = _xRotation;
            
            _yRotation = cameraRoot.localEulerAngles.y;
            if (_yRotation > 180) _yRotation -= 360;
            _smoothYRotation = _yRotation;
        }
        
        // Hide and lock cursor
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
        
        if (lookAction != null && lookAction.action != null) lookAction.action.Enable();
        if (moveAction != null && moveAction.action != null) moveAction.action.Enable();
    }

    private void Update()
    {
        HandleRotation();
        HandleBobbingAndDip();
    }

    private void HandleRotation()
    {
        if (lookAction == null || lookAction.action == null || !lookAction.action.enabled) return;
        
        Vector2 lookInput = lookAction.action.ReadValue<Vector2>();

        // Add Left Stick input if contextual condition is met
        if (climbStateManager != null && climbStateManager.IsLeftStickCameraActive && moveAction != null)
        {
            lookInput += moveAction.action.ReadValue<Vector2>();
        }

        // Use Time.deltaTime to ensure frame-rate independence and smooth joystick movement
        // Scaling by 150f to maintain a good default feel with sensitivity 1.0
        float lookX = lookInput.x * lookSensitivity * 150f * Time.deltaTime;
        float lookY = lookInput.y * lookSensitivity * 150f * Time.deltaTime;

        _xRotation -= lookY;
        _xRotation = Mathf.Clamp(_xRotation, -xRotationLimit, xRotationLimit);

        bool isClimbing = climbStateManager != null && climbStateManager.CurrentState != ClimbStateManager.ClimbState.Idle;

        // Smoothing for all axes
        _smoothXRotation = Mathf.Lerp(_smoothXRotation, _xRotation, Time.deltaTime * lookSmoothing);

        if (isClimbing)
        {
            // --- CLIMBING MODE ---
            // Horizontal look rotates the camera relative to the body
            _yRotation += lookX;
            _smoothYRotation = Mathf.Lerp(_smoothYRotation, _yRotation, Time.deltaTime * lookSmoothing);

            if (cameraRoot != null)
            {
                cameraRoot.localRotation = Quaternion.Euler(_smoothXRotation, _smoothYRotation, 0f);
            }
            
            _wasClimbing = true;
        }
        else
        {
            // --- WALKING MODE ---
            // If we just finished climbing, transfer the camera's local yaw to the body's yaw
            if (_wasClimbing)
            {
                _bodyYaw += _yRotation;
                _smoothBodyYaw = _bodyYaw; // Snap smooth yaw to current to avoid a slow pan back
                _yRotation = 0f;
                _smoothYRotation = 0f;
                _wasClimbing = false;
                
                if (cameraRoot != null)
                {
                    cameraRoot.localRotation = Quaternion.Euler(_smoothXRotation, 0f, 0f);
                }
            }

            // Horizontal look rotates the player body
            _bodyYaw += lookX;
            _smoothBodyYaw = Mathf.Lerp(_smoothBodyYaw, _bodyYaw, Time.deltaTime * lookSmoothing);

            // Set absolute rotation to avoid jitter and ensure compatibility with interpolated Rigidbody
            transform.rotation = Quaternion.Euler(0f, _smoothBodyYaw, 0f);

            if (cameraRoot != null)
            {
                cameraRoot.localRotation = Quaternion.Euler(_smoothXRotation, 0f, 0f);
            }
        }
    }

    private void HandleBobbingAndDip()
    {
        if (cameraRoot == null) return;

        // --- Bobbing Logic ---
        if (_rb != null)
        {
            Vector3 horizontalVel = new Vector3(_rb.linearVelocity.x, 0, _rb.linearVelocity.z);
            float speed = horizontalVel.magnitude;
            bool isClimbing = climbStateManager != null && climbStateManager.CurrentState != ClimbStateManager.ClimbState.Idle;

            if (speed > 0.1f && !isClimbing)
            {
                _bobTimer += Time.deltaTime * speed * bobFrequency;
                float xOffset = Mathf.Cos(_bobTimer * 0.5f) * bobHorizontalAmount;
                float yOffset = Mathf.Sin(_bobTimer) * bobVerticalAmount;
                _currentBobOffset = Vector3.Lerp(_currentBobOffset, new Vector3(xOffset, yOffset, 0), Time.deltaTime * bobSmoothing);
            }
            else
            {
                _bobTimer = 0;
                _currentBobOffset = Vector3.Lerp(_currentBobOffset, Vector3.zero, Time.deltaTime * bobSmoothing);
            }
        }

        // --- Landing Dip Logic ---
        _landingDipAmount = Mathf.Lerp(_landingDipAmount, 0, Time.deltaTime * 5f);

        // --- Apply Both ---
        cameraRoot.localPosition = _initialCameraPos + _currentBobOffset - (Vector3.up * _landingDipAmount);
    }

    public void TriggerLandingDip(float intensity)
    {
        _landingDipAmount = intensity;
    }
}
