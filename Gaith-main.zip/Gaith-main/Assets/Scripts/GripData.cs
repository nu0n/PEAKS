using UnityEngine;

/// <summary>
/// Stores everything about one hand grip point.
/// </summary>
public struct GripData
{
    public bool     isActive;
    public Vector3  worldPosition;   // exact surface point
    public Vector3  surfaceNormal;   // normal at hit
    public Transform attachedTo;     // transform of the surface part (tracks moving platforms)
    public Vector3  localPosition;   // position in surface's local space (for moving platforms)

    public static GripData Empty => new GripData { isActive = false };

    /// <summary>Current world position, accounting for moving platforms.</summary>
    public Vector3 CurrentWorldPosition =>
        attachedTo != null ? attachedTo.TransformPoint(localPosition) : worldPosition;
}
