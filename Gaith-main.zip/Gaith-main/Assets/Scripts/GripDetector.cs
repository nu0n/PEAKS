using UnityEngine;

/// <summary>
/// Casts a ray from the camera through the mouse position.
/// Returns a GripData if a ClimbSurface is within reach.
/// </summary>
public class GripDetector : MonoBehaviour
{
    [Header("References")]
    public Camera playerCamera;

    [Header("Settings")]
    public float maxReachDistance = 2.5f;   // Increased slightly for better lateral traversal
    public float magneticRadius = 0.5f; // Radius for 'snapping' to ledges
public LayerMask climbableLayer;    // set to "Climbable" layer in Inspector

    /// <summary>
    /// Call with a screen position.
    /// Returns GripData.Empty if nothing grippable is hit.
    /// </summary>
    public GripData TryGetGrip(Vector2 screenPosition)
    {
        Ray ray = playerCamera.ScreenPointToRay(screenPosition);

        // Use SphereCast for 'Magnetic' snapping to ledges
        if (Physics.SphereCast(ray, magneticRadius, out RaycastHit hit, maxReachDistance * 6f, climbableLayer))
        {
            // Check distance from the player (not camera)
            float dist = Vector3.Distance(transform.position, hit.point);
            if (dist > maxReachDistance + magneticRadius) return GripData.Empty;

            ClimbSurface surface = hit.collider.GetComponent<ClimbSurface>();
            if (surface == null) return GripData.Empty;

            return new GripData
            {
                isActive       = true,
                worldPosition  = hit.point,
                surfaceNormal  = hit.normal,
                attachedTo     = hit.transform,
                localPosition  = hit.transform.InverseTransformPoint(hit.point)
            };
        }

        return GripData.Empty;
    }
}
