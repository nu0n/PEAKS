using UnityEngine;

/// <summary>
/// Updates the positions of UI reticles on the screen based on ClimbStateManager's stick inputs.
/// </summary>
public class ClimbReticleManager : MonoBehaviour
{
    [Header("References")]
    public ClimbStateManager stateManager;
    public RectTransform leftReticle;
    public RectTransform rightReticle;

    private void Start()
    {
        // Try to find state manager if not assigned
        if (stateManager == null)
            stateManager = Object.FindAnyObjectByType<ClimbStateManager>();
}

    private void Update()
    {
        if (stateManager == null) return;

        if (leftReticle != null)
        {
            leftReticle.position = stateManager.LeftScreenPos;
        }

        if (rightReticle != null)
        {
            rightReticle.position = stateManager.RightScreenPos;
        }
    }
}
