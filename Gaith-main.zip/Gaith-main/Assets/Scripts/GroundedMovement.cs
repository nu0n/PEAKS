using UnityEngine;
using UnityEngine.InputSystem;

[RequireComponent(typeof(Rigidbody))]
public class GroundedMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    public float maxSpeed = 8.5f;
    public float acceleration = 100f;
    public float friction = 12f;
    public float airAcceleration = 20f;
    public float jumpForce = 9.5f;

    [Header("Inertia Settings")]
    public float inertiaBaseMultiplier = 0.5f; // Initial acceleration multiplier
    public float inertiaRampSpeed = 2.0f;      // How fast acceleration returns to 100%
    public float turnThreshold = 0.2f;         // Dot product threshold for "sharp turn"

    [Header("Ground Detection")]
public float groundCheckDistance = 1.1f; // Adjust based on capsule half-height + small offset
    public LayerMask groundMask;

    [Header("References")]
    public InputActionReference moveAction;
    public InputActionReference jumpAction;
    public ClimbStateManager climbStateManager;
    public PlayerLook playerLook;

    private Rigidbody _rb;
    private bool _isGrounded;
    private bool _wasGrounded;
    private float _currentInertiaMultiplier = 1.0f;

    private void Awake()
{
        _rb = GetComponent<Rigidbody>();
    }

    private void OnEnable()
    {
        if (moveAction != null && moveAction.action != null) moveAction.action.Enable();
        if (jumpAction != null && jumpAction.action != null)
        {
            jumpAction.action.Enable();
            jumpAction.action.started += OnJump;
        }
    }

    private void OnDisable()
    {
        if (jumpAction != null && jumpAction.action != null) jumpAction.action.started -= OnJump;
    }

    private void FixedUpdate()
    {
        // Don't move if we are climbing
        if (climbStateManager != null && climbStateManager.CurrentState != ClimbStateManager.ClimbState.Idle)
            return;

        CheckGround();
        
        // Impact Detection
        if (_isGrounded && !_wasGrounded)
        {
            float impactForce = Mathf.Abs(_rb.linearVelocity.y);
            if (impactForce > 2f && playerLook != null)
            {
                playerLook.TriggerLandingDip(impactForce * 0.05f);
            }
        }
        _wasGrounded = _isGrounded;

        HandleMovement();
    }

    private void CheckGround()
    {
        // Use SphereCast for more stable grounding on slopes and edges
        float radius = 0.45f; // Slightly smaller than capsule radius
        float castDistance = groundCheckDistance - radius;
        _isGrounded = Physics.SphereCast(transform.position + Vector3.up * radius, radius, Vector3.down, out RaycastHit hit, castDistance + 0.1f, groundMask);
    }

    private void HandleMovement()
    {
        Vector2 input = (moveAction != null && moveAction.action != null) ? moveAction.action.ReadValue<Vector2>() : Vector2.zero;
        
        // Transform input to world space
        Vector3 moveDir = transform.right * input.x + transform.forward * input.y;
        
        if (moveDir.magnitude > 1f) moveDir.Normalize();

        Vector3 currentVelocity = _rb.linearVelocity;
        Vector3 horizontalVelocity = new Vector3(currentVelocity.x, 0, currentVelocity.z);

        if (_isGrounded)
        {
            ApplyFriction(horizontalVelocity);
            
            // --- Improved Inertia Logic ---
            if (moveDir.sqrMagnitude > 0.001f)
            {
                // If moving and switching direction, reset the multiplier
                if (horizontalVelocity.sqrMagnitude > 0.1f)
                {
                    float dot = Vector3.Dot(horizontalVelocity.normalized, moveDir.normalized);
                    if (dot < turnThreshold)
                    {
                        _currentInertiaMultiplier = inertiaBaseMultiplier;
                    }
                }
                
                // Ramp up the multiplier
                _currentInertiaMultiplier = Mathf.MoveTowards(_currentInertiaMultiplier, 1.0f, inertiaRampSpeed * Time.fixedDeltaTime);
                
                Accelerate(moveDir, horizontalVelocity, acceleration * _currentInertiaMultiplier, maxSpeed);
            }
            else
            {
                // Reset multiplier when not moving
                _currentInertiaMultiplier = inertiaBaseMultiplier;
            }
        }
        else
        {
            // Air control - Strictly additive as per plan
            if (moveDir.sqrMagnitude > 0.001f)
            {
                Accelerate(moveDir, horizontalVelocity, airAcceleration, maxSpeed);
            }
        }
    }

    private void Accelerate(Vector3 moveDir, Vector3 currentVelocity, float accel, float targetSpeed)
    {
        // Calculate the component of current velocity in the direction of movement
        float currentSpeed = Vector3.Dot(currentVelocity, moveDir);
        
        // Calculate how much speed we want to add
        float addSpeed = targetSpeed - currentSpeed;
        
        if (addSpeed <= 0) return;

        // Calculate actual acceleration speed for this frame
        float accelSpeed = accel * Time.fixedDeltaTime;
        
        // Clamp acceleration speed so we don't overshoot target speed
        if (accelSpeed > addSpeed) accelSpeed = addSpeed;

        _rb.AddForce(moveDir * accelSpeed, ForceMode.VelocityChange);
    }

    private void ApplyFriction(Vector3 currentVelocity)
    {
        float speed = currentVelocity.magnitude;
        if (speed < 0.01f)
        {
            // Fully stop if very slow to avoid jitter
            _rb.linearVelocity = new Vector3(0, _rb.linearVelocity.y, 0);
            return;
        }

        // Project-specific friction logic (Industry Standard "Drop" method)
        float frictionValue = friction;
        
        // If speed is below a threshold, apply a minimum friction to ensure stopping
        float control = speed < 1.0f ? 1.0f : speed;
        float drop = control * frictionValue * Time.fixedDeltaTime;
        
        float newSpeed = speed - drop;
        if (newSpeed < 0) newSpeed = 0;

        float multiplier = newSpeed / speed;
        _rb.linearVelocity = new Vector3(currentVelocity.x * multiplier, _rb.linearVelocity.y, currentVelocity.z * multiplier);
    }

    private void OnJump(InputAction.CallbackContext ctx)
    {
        if (_isGrounded && (climbStateManager == null || climbStateManager.CurrentState == ClimbStateManager.ClimbState.Idle))
        {
            // Reset Y velocity for consistent jump height
            _rb.linearVelocity = new Vector3(_rb.linearVelocity.x, 0f, _rb.linearVelocity.z);
            _rb.AddForce(Vector3.up * jumpForce, ForceMode.VelocityChange);
        }
    }
}
