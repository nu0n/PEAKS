# Project Overview
- Game Title: Climbing System Test
- High-Level Concept: Debugging and refining the climbing physics and state management.
- Players: Single player
- Target Platform: PC (Windows)

# Game Mechanics
## Core Gameplay Loop
The player grips ledges and moves. We are currently troubleshooting "moving far away" behavior when gripping.

# UI
- Debug logging in the Console.

# Key Asset & Context
- `ClimbBodyPhysics.cs`: Handles the spring-damper physics for movement.
- `ClimbStateManager.cs`: Handles input and state transitions.
- `ThrottledLogHandler.cs`: Existing utility that throttles identical logs, but needs careful usage with dynamic values.

# Implementation Steps
1. **Improve Physics Logging in `ClimbBodyPhysics.cs`**:
    - Add detailed logging to `FixedUpdate` that includes:
        - Current Velocity (`_rb.linearVelocity`).
        - Breakout of Spring Force vs. Damping Force.
        - The direction and magnitude of the `wallNormal`.
        - The calculated `targetPos` relative to the player.
    - Implement a more robust 15-second cooldown that doesn't rely on string matching (since values change every frame). Use a `_lastPhysicsLogTime` variable.
2. **Improve State Logging in `ClimbStateManager.cs`**:
    - Add logging for grip attempts (distance to surface, normal).
    - Add logging for state transitions (e.g., Idle -> LeftGrip).
    - Use a similar 15-second cooldown for repetitive state logs.
3. **Analyze and Adjust `bodyDepthOffset`**:
    - Ensure `bodyDepthOffset` isn't pushing the player too far.
    - Log the distance between the player and the wall during a grip.

# Verification & Testing
1. Enter Play Mode.
2. Approach a ledge and grip it.
3. Observe the Console for the detailed physics breakdown.
4. Verify that logs only appear every 15 seconds even as values change.
5. Check if the "moving far away" behavior is explained by the logged forces.
