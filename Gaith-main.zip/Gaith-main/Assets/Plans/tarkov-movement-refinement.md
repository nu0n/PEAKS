# Project Overview
- Game Title: First Person Climber
- High-Level Concept: Realistic first-person movement and climbing.
- Reference Game: Escape from Tarkov (Weight, Inertia, High Gravity).
- Players: Single player.
- Target Platform: PC.
- Render Pipeline: HDRP.

# Game Mechanics
## Core Gameplay Loop
- Tactical movement with weight and inertia.
- High gravity for a "heavy" grounded feel.
- Climbing mechanics requiring momentum management.

## Controls and Input Methods
- WASD for movement.
- Space for Jump.
- Rigidbody-based physics for responsive but weighted feel.

# UI
- Standard HUD (not the focus of this task).

# Key Asset & Context
- **GroundedMovement.cs**: Main movement script. Needs better air control and inertia logic.
- **ClimbBodyPhysics.cs**: Handles kinematic climbing and jumping off walls.
- **Physics Settings**: Gravity is set to -18.
- **Rigidbody Settings**: Ensure `linearDamping` is 0 to avoid constant force fighting.

# Implementation Steps

## 1. GroundedMovement Refinement
- **Parameters Tuning**:
    - Update `maxSpeed` to 8.5.
    - Update `acceleration` to 100 (for ground responsiveness).
    - Update `jumpForce` to 9.5 (middle of 8-10 range) to balance the -18 gravity.
    - Update `friction` to 12.
- **Improved Inertia Logic**:
    - Replace the instant velocity penalty with a directional inertia system.
    - When changing direction (dot product of velocity and input < threshold), apply a temporary acceleration reduction or a counter-force to simulate shifting weight.
    - Implement a "Speed Multiplier" that ramps up when starting movement or switching directions, rather than reaching full speed instantly.

## 2. Air Control Improvements
- Adjust `airAcceleration` to be responsive enough to nudge direction without allowing mid-air reversals (typical of Tarkov).
- Ensure horizontal velocity is preserved more strictly in the air.

## 3. Climbing Momentum Handover
- **ClimbBodyPhysics.cs**:
    - Review the velocity buffer tracking (current 8 frames).
    - Ensure `Jump` direction calculation is "clean" (blending forward and up correctly).
    - Add a small "kick" force when jumping off walls to ensure clearance.

## 4. Component Verification
- Verify `linearDamping` and `angularDamping` are set to 0 and 0.05 respectively on the Player Rigidbody.

# Verification & Testing
- **Speed Test**: Measure time to cover 10m; target ~1.2s (8.5m/s).
- **Jump Test**: Verify ability to jump over 0.75m obstacles with -18 gravity.
- **Inertia Test**: Perform "A-D strafe" and verify the character takes a moment to switch direction (no instant snap).
- **Climb-to-Jump Test**: Jump off a wall and ensure the character launches away from the wall with sufficient speed.
