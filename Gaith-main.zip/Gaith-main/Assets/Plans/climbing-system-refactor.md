# Project Overview
- Game Title: VR-Inspired Climbing System
- High-Level Concept: A physics-based first-person climbing game using dual-stick/trigger controls for hand-over-hand traversal.
- Players: Single player
- Target Platform: PC (Standalone Windows)
- Input System: New Input System
- Render Pipeline: HDRP

# Problem Analysis
1. **Redundancy:** `ClimbStateManager` contains duplicate logic for left and right hands.
2. **Performance:** `CheckCrumblingGrips` calls `GetComponent` every frame.
3. **Camera Instability:** While climbing, the camera rotates automatically when the player's body aligns with wall normals, which can feel disorienting.
4. **Input Conflict:** The Left Stick can unintentionally trigger body swinging while the player is trying to aim their hand or rotate the camera.
5. **Detection Efficiency:** The `GripDetector` sphere-cast range is wider than necessary.

# Proposed Changes
## 1. Code Optimization (DRY & Performance)
- **Modify `GripData.cs`**: Add `public ClimbSurface surface;` to the struct to cache component references.
- **Update `GripDetector.cs`**: 
  - Limit `SphereCast` range to `maxReachDistance + magneticRadius`.
  - Assign the `ClimbSurface` component to the `GripData` result.
- **Update `ClimbStateManager.cs`**:
  - Implement a `ProcessHand(ref GripData grip, bool isLeft, ...)` helper method to handle stick aiming and gripping logic for both hands, reducing duplicate code.
  - Refactor `CheckCrumblingGrip` to use the cached `surface` in `GripData`.

## 2. World-Stable Camera Logic
- **Update `PlayerLook.cs`**:
  - Implement rotation compensation: while climbing, track the change in the character body's Y-rotation and subtract it from the `cameraRoot`'s local rotation. This ensures the camera maintains its world-space direction unless explicitly moved by the sticks.

## 3. Input Conflict Resolution
- **Update `ClimbStateManager.cs`**:
  - In `HandleBodyInput`, check `IsLeftStickCameraActive` before calling `bodyPhysics.ApplySwing`. If the stick is being used for the camera, disable swing input.

## 4. Configuration & Polish
- **Update `ClimbBodyPhysics.cs` & `HandController.cs`**:
  - Replace magic numbers (offsets, smoothing times, jump weights) with `[SerializeField]` variables.
- **Update `ClimbReticleManager.cs`**:
  - Use `RectTransformUtility.ScreenPointToLocalPointInRectangle` for robust UI positioning across different resolutions.

# Implementation Steps
1. **Data & Detection Layer**: Update `GripData` and `GripDetector`. (Dependency: None)
2. **State Management Refactor**: Implement `ProcessHand` and update crumbling logic in `ClimbStateManager`. (Dependency: Step 1)
3. **Camera & Input Polish**: Implement world-stable rotation in `PlayerLook` and resolve stick conflict in `ClimbStateManager`. (Dependency: Step 2)
4. **Inspector Exposure**: Expose configuration variables in physics and hand scripts. (Dependency: None)

# Verification & Testing
1. **DRY Verification**: Ensure both hands behave identically with the new `ProcessHand` logic.
2. **Camera Stability Test**: Climb around a curved wall or corner. Verify the camera stays facing the same world direction until the stick is used.
3. **Input Separation**: Confirm that aiming the left hand (while gripping with the right) rotates the camera but does *not* swing the body.
4. **Performance Check**: Verify `GetComponent` is no longer called in `Update`.
5. **Resolution Test**: Change screen aspect ratio and verify UI reticles stay centered on grip points.
