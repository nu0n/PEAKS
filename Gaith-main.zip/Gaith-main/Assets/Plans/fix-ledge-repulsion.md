# Project Overview
- Game Title: Climbing System Test
- High-Level Concept: Fixing player repulsion from ledges by refining geometry and physics offsets.

# Game Mechanics
## Core Gameplay Loop
The player grips thin ledges. We need to ensure the character's collision capsule doesn't overlap with the wall/ledge while hanging.

# Key Asset & Context
- `ClimbBodyPhysics.cs`: Adjusting `bodyDepthOffset` and damping.
- Ledges: Scaling and positioning to be thin window sills.

# Implementation Steps
1. **Update `ClimbBodyPhysics.cs`**:
    - Set `bodyDepthOffset` to `0.7f`. (This is > 0.5m capsule radius, providing 0.2m clearance).
    - Increase `pullForce` to `60f` and `dampingForce` to `20f` for rock-solid stability.
2. **Update Ledge Geometry**:
    - Set all ledges to be thin: World Scale (1.5, 0.05, 0.1).
    - Position ledges exactly on the wall face (Z=4.45).
3. **Verify**:
    - Enter Play Mode.
    - Grab a ledge.
    - Check if the player stays steady without moving away.

# Verification & Testing
1. Grab a ledge.
2. Observe Console: `DistToWall` should be approx `0.7m`.
3. Check for any "jitter" or explosive movement.
