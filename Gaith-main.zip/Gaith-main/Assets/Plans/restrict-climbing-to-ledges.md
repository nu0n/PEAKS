# Project Overview
- Game Title: Climbing System Test
- High-Level Concept: Restricting climbing to specific ledges only, preventing "Spider-Man" behavior on flat walls.

# Game Mechanics
## Core Gameplay Loop
The player should only be able to grip onto explicit ledges, not the main wall structure.

# Key Asset & Context
- `ClimbingWall`: The background structure. Should NOT be climbable.
- `Ledge_Base_1`, etc.: The specific grip points. Should be climbable.
- `ClimbSurface.cs`: The component that identifies a climbable object.

# Implementation Steps
1. **Remove `ClimbSurface` from `ClimbingWall`**:
    - This component automatically sets the layer to "Climbable".
2. **Reset `ClimbingWall` Layer**:
    - Set it to "Default" so the `GripDetector` ignores it.
3. **Make Ledges More Prominent**:
    - Update all ledge GameObjects (Cubes) to have a more prominent "window sill" or "roof edge" appearance.
    - Set `World Scale` to approx (3.0, 0.1, 0.3).
    - Adjust positions so they stick out significantly from the wall face.
4. **Verify Ledge Configuration**:
    - Ensure all ledge GameObjects have `ClimbSurface` and are on the "Climbable" layer.
5. **Test**:
    - Attempt to grab the flat wall (should fail).
    - Attempt to grab a prominent ledge (should succeed).

# Verification & Testing
1. Approach the wall.
2. Click on the flat surface of the wall. Verify no grip is established.
3. Click on a ledge. Verify the grip is successful and the character hangs at the correct distance.
