# Project Overview
- Game Title: Unnamed Climbing System
- High-Level Concept: First-person physics-based movement and climbing system.
- Players: Single player
- Inspiration: Roblox Climbing, Half-Life (grounded physics)
- Tone / Art Direction: Realistic/Physics-focused
- Target Platform: PC
- Render Pipeline: HDRP

# Game Mechanics
## Core Gameplay Loop
Players explore the environment using grounded physics-based movement (tuned for a Half-Life/Source feel). When encountering climbable surfaces (tagged/layered "Climbable"), players can grip onto them with either hand (Left/Right Mouse Buttons). Climbing involves swinging the body to reach higher points and releasing/jumping to transition back to grounded movement.

## Controls and Input Methods
- **WASD**: Grounded movement / Air control / Climbing swing.
- **Mouse Movement**: First-person look (refined sensitivity).
- **Left Mouse Button**: Grip with left hand (Red visual indicator).
- **Right Mouse Button**: Grip with right hand (Blue visual indicator).
- **Space**: Jump / Release from climb.

# UI
- No major UI required for this task. Rudimentary 3D visuals are used for hands.

# Key Asset & Context
- `InputSystem_Actions.inputactions`: The central input configuration.
- `ClimbStateManager.cs`: Manages the transition between movement states.
- `ClimbBodyPhysics.cs`: Handles physics forces during climbing.
- `GroundedMovement.cs` (New): Handles Half-Life style physics movement.
- `FirstPersonCamera.cs` (New): Handles mouse look and camera positioning.
- `CinemachineCamera`: For smooth first-person tracking.

# Implementation Steps
## 1. Input Action Configuration
- Update `Assets/InputSystem_Actions.inputactions`:
    - Add `GripLeft` (Button, `<Mouse>/leftButton`).
    - Add `GripRight` (Button, `<Mouse>/rightButton`).
    - Ensure `Move`, `Look`, and `Jump` are correctly mapped.

## 2. First Person Look System
- Implement `PlayerLook.cs`:
    - Controls vertical camera rotation (clamped).
    - Controls horizontal player rotation.
    - Locks the cursor during gameplay.
- Setup Cinemachine:
    - Add a `CinemachineCamera` to the scene.
    - Set it to "First Person" or "Orbital" with offsets to match the player's head.
    - Assign the `PlayerLook` script to manage the input.

## 3. Grounded Movement Implementation
- Implement `GroundedMovement.cs`:
    - Uses `Rigidbody` for movement.
    - Implements acceleration-based movement (Source/Quake style) for a "Half-Life" feel (High acceleration, high friction, air strafing).
    - Includes ground detection (Raycast or SphereCast).
    - **Dependency**: Must check `ClimbStateManager.CurrentState` to disable grounded forces while climbing.

## 4. Climbing System Integration
- Update `ClimbStateManager.cs`:
    - Fix the `Debug.LogError` regarding missing Input Actions by ensuring references are correctly initialized or found.
    - Connect the new `GripLeft` and `GripRight` actions.
- Update `ClimbBodyPhysics.cs`:
    - Ensure it properly hands off control back to `GroundedMovement` when releasing.
    - Tweak swing and jump forces for more dynamic climbing.

## 5. Hand Visualization and Tuning
- Add rudimentary visualizers (Cubes) to the IK targets of the hands.
- Tune `HandController` idle offsets for better first-person visibility.
- Refine `PlayerLook` and `GroundedMovement` parameters to match Half-Life responsiveness.

## 6. Scene Setup and Wiring
- Configure the `Player` prefab/object:
    - Assign all missing `InputActionReference` fields in `ClimbStateManager`.
    - Setup `CameraRoot` and `Main Camera` with Cinemachine.
    - Configure `Rigidbody` settings (Mass: 80, Drag: 2, Freeze X/Z Rotation, Interpolation enabled).
    - Setup Layers (8: Climbable, 9: Player).

# Verification & Testing
- **Grounded Movement**: Verify that the player moves with momentum and can jump.
- **Camera**: Verify the first-person look is smooth and clamped.
- **Climbing**: Verify that Left/Right mouse buttons trigger grips on "Climbable" surfaces.
- **Transitions**: Verify that jumping while climbing releases the player into grounded physics.
- **Logs**: Ensure no "Action is missing" errors appear in the console.
