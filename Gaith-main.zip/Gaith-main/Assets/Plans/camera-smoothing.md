# Project Overview
- Game Title: First Person Climber
- High-Level Concept: A first-person climbing game where the player uses dual-stick or trigger-modified controls to navigate surfaces.
- Players: Single player
- Inspiration / Reference Games: Grow Home, Mirror's Edge, VR Climbing games
- Tone / Art Direction: HDRP High Fidelity (Realistic/Stylized)
- Target Platform: PC (StandaloneWindows64)
- Screen Orientation / Resolution: Landscape 1920x1080
- Render Pipeline: HDRP
- Input System: New Input System

# Game Mechanics
## Core Gameplay Loop
- Move and look around.
- Approach climbable surfaces.
- Use triggers to grip and sticks to reach for points.
- Physics-based movement and swinging while climbing.

## Controls and Input Methods
- Movement: Left Stick
- Look: Right Stick
- Grip: Left/Right Triggers (L2/R2)
- Jump: Button South (A)

# UI
- Reticles for left/right hand reach.
- HUD for stamina or grip status (if implemented).

# Key Asset & Context
- **PlayerLook.cs**: Handles camera rotation, head bobbing, and landing dips.
- **FirstPersonVCam**: The Cinemachine Virtual Camera following the player.
- **CinemachineBrain**: Manages camera updates and blending.

# Implementation Steps
1. **Modify PlayerLook.cs for Full Rotation Smoothing**:
   - Add `lookSmoothing` property (if not already there).
   - Multiply all look inputs by `Time.deltaTime` to ensure frame-rate independence (crucial for joysticks).
   - Implement smoothing for horizontal rotation by accumulating it into `_yRotation` and lerping `_smoothYRotation` even when not climbing.
   - Apply the smoothed horizontal rotation to the body (`transform`) when walking, and to the `cameraRoot` when climbing.
   - Ensure transitions between climbing and walking (rotation transfer) are handled smoothly.
   
2. **Configure CinemachineBrain Update Method**:
   - Set `Update Method` to `Late Update` to ensure the camera follows the player's interpolated Rigidbody transform at the very end of the frame, reducing position jitter.
   
3. **Verify Rigidbody Interpolation**:
   - (Already verified as enabled, but keep as a checklist item).

4. **Tune Bobbing and Landing Dip**:
   - Ensure the `localPosition` changes in `HandleBobbing` and `HandleLandingDip` are also well-integrated with the smoothed rotation.

# Verification & Testing
- **Manual Test**: Move the mouse/stick rapidly and check for micro-jitters.
- **Manual Test**: Move the player character while looking around to ensure no "trailing" or "ghosting" of the camera.
- **Manual Test**: Test climbing transitions (where horizontal rotation transfers between camera root and player body) to ensure smoothness.
- **Performance Check**: Ensure no significant overhead from interpolation logic.
