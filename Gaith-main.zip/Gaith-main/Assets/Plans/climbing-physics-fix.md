# Project Overview
- Game Title: Climbing Test
- High-Level Concept: Technical test for a climbing system with raycast-based grip detection.
- Render Pipeline: HDRP
- Input System: New Input System

# Key Asset & Context
- `ClimbingWall`: The structure the player climbs.
- `ClimbBodyPhysics.cs`: Handles forces and body orientation.
- `ThrottledLogHandler.cs`: Controls log frequency.

# Implementation Steps (Final Phase)
1. **Stabilize Logging System**
   - Update `LogManager.cs` to prevent multiple wrappings of the log handler.
2. **Fix Climbing Physics**
   - In `ClimbBodyPhysics.cs`:
     - Clear velocity on grip to prevent sliding away.
     - Change rotation to face the wall (`-wallNormal`).
     - Remove redundant `Time.fixedDeltaTime` from `AddForce` calls.
     - Update default values for better feel (`pullForce=1800`, `dampingForce=16`, `bodyHangOffset=1.2`).
3. **Refine Debug Information**
   - Format physics logs to `:F1` so the throttle correctly identifies repeated data.

# Verification & Testing
- Grab the 2m ledge; check that the character hangs stably at 0.8m height (Y).
- Check that the character faces the wall.
- Confirm console logs for `[ClimbPhysics]` only appear every 15 seconds.
