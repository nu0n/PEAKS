# Bug Fix Plan - Climb System
## 1. NullReferenceException in ClimbStateManager.cs
- **Cause**: `InputActionReference` variables (`gripLeftAction`, `gripRightAction`, `moveAction`, `jumpAction`) are declared but not assigned in the Inspector, or their `.action` property is null because they haven't been enabled or associated with an asset.
- **Solution**: 
    - Add null checks before accessing `.action`.
    - Log a helpful error if they are missing.
    - Call `.action.Enable()` in `OnEnable`.

## 2. Log Throttling
- **Requirement**: "Improve console logs so they don't repeat more than twice every 315 seconds".
- **Solution**: Implement a static log throttler in `ClimbStateManager` (or a helper class) that tracks the message, frequency, and timestamp.

## 3. Duplicate AudioListener
- **Cause**: The `Player` setup script created a new `Main Camera` with an `AudioListener`, while the scene already had one.
- **Solution**: Find and destroy the `AudioListener` on the player's camera if another one exists in the scene, or just remove the `AddComponent<AudioListener>()` from the player setup.

## 4. Implementation Steps
1. Update `ClimbStateManager.cs` with null checks and `ThrottledLog` logic.
2. Run a script to cleanup the existing scene (remove duplicate `AudioListener`).
3. Verify that the system no longer crashes when unassigned.
