# Project Overview
- Game Title: VR/First-Person Climbing & Locomotion
- High-Level Concept: A physics-based movement and climbing system with IK hands.
- Players: Single player.
- Inspiration / Reference Games: Mirror's Edge, Climbey, Boneworks.
- Tone / Art Direction: Minimalist/Technical (Ghost hands).
- Target Platform: Standalone (potentially VR-ready).
- Render Pipeline: HDRP.

# Game Mechanics
## Core Gameplay Loop
The player explores an environment by walking and climbing surfaces. The focus is on the tactile feel of movement and the physical connection between the player's hands and the environment.

## Controls and Input Methods
- **Locomotion**: Left stick / WASD for ground movement.
- **Climbing**: Grip buttons (or triggers) to grab surfaces.
- **Camera**: Right stick / Mouse for looking.
- **Jumping**: Space / A-button.

# UI
- **Grip Reticles**: Visual indicators on the screen/hands showing reachable climbing points (handled by `ClimbReticleManager`).
- **Grip Preview**: Faded hand indicators showing where a grip will land.

# Key Asset & Context
- `ClimbBodyPhysics.cs`: Manages kinematic body positioning during climbing.
- `HandController.cs`: Controls IK targets using Animation Rigging.
- `GroundedMovement.cs`: Handles ground locomotion via Rigidbody forces.
- `ClimbStateManager.cs`: Central hub for input and state logic.
- `PlayerLook.cs`: Handles camera rotation.

# Implementation Steps
## Phase 1: Smoothing & Organic Motion
1. **Refactor `HandController.cs`**:
   - Replace linear `Vector3.Lerp` in `Update()` and `ApplyGrip()` with `Vector3.SmoothDamp` for position and `Quaternion.Slerp` for rotation.
   - Introduce a "Reaching" state: When `_previewGrip` is active but not yet grabbed, use a slower smoothing speed to simulate a cautious reach.
   - **Dependency**: Existing `Animation Rigging` setup.
2. **Refactor `ClimbBodyPhysics.cs`**:
   - Change the kinematic position update (`nextPos` calculation) to use `SmoothDamp` to avoid the "springy" feel of `Lerp`.
   - Add a "Body Sag" offset: If only one hand is gripped, add a slight rotation/tilt toward the free-hand side to simulate gravity's effect on the torso.

## Phase 2: Locomotion Polish & Transitions
1. **Momentum Handover**:
   - Modify `ClimbStateManager.cs` to capture `_rb.linearVelocity` from `GroundedMovement` the moment a climb starts.
   - Pass this velocity to `ClimbBodyPhysics.SetGrips` to initialize the `_swingVelocity` buffer, allowing the player to "vault" onto walls with speed.
2. **Procedural Camera Bob (`PlayerLook.cs`)**:
   - Add a `bobFrequency` and `bobAmount`.
   - In `Update`, calculate a vertical and horizontal offset using `Mathf.Sin(Time.time * freq) * horizontalSpeed`.
   - Apply this offset to the `cameraRoot` local position.

## Phase 3: Secondary "Human" Cues
1. **Breathing/Idle Noise**:
   - Add a low-frequency Perlin noise to the `idlePositionOffset` in `HandController.cs` to make the hands feel alive when the player is standing still.
2. **Impact Damping**:
   - When landing from a jump (`isGrounded` becomes true in `GroundedMovement.cs`), trigger a brief camera "dip" and a hand "drop" to simulate the impact being absorbed by the knees and arms.

## Phase 4: Realistic Hand Framing & "Sticky" Cursor
1. **Lateral Hand Framing (`ClimbStateManager.cs`)**:
   - Update `HandleHandInput` to use a side-based screen center for the left and right reticles (e.g., center-left for left hand, center-right for right hand).
   - Add a `verticalOffset` to keep hands at a natural waist/chest height rather than perfectly centered.
2. **"Sticky" Ghost Hands (`GripPreviewManager.cs`)**:
   - Implement a "Ledge Lock": When a ghost hand finds a grip, it should stay "stuck" to that world position even if the player moves the reticle slightly, until a distance threshold is exceeded.
   - This prevents the hands from "vibrating" or sliding too easily when trying to focus on a specific ledge.
3. **Ghost Hand Transition Polish**:
   - Add a fading effect (via Material property or SpriteRenderer alpha) when a Ghost Hand loses its grip, rather than a hard `SetActive(false)`.
