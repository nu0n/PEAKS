# Project Overview
- Game Title: Physics Hand-Grip Climbing System
- High-Level Concept: A robust climbing system using physics-based hand-grip mechanics, allowing players to swing, jump, and climb across various surfaces with realistic body physics and hand IK.
- Players: Single player
- Tone / Art Direction: Realistic / Functional
- Target Platform: PC (Standalone Windows)
- Screen Orientation / Resolution: Landscape 1920x1080
- Render Pipeline: HDRP

# Game Mechanics
## Core Gameplay Loop
1. **Grip Detection**: The system casts a ray from the camera to detect climbable surfaces within reach.
2. **IK Hand Positioning**: Two-bone IK constraints drive hands to grip points on the surface.
3. **Body Physics**: A spring-damper system pulls the player toward a calculated anchor point between active grips, maintaining a realistic hang distance.
4. **Swing & Jump**: Players can influence their body swing using WASD and perform explosive jumps to transition between holds or detach.

## Controls and Input Methods
- **Grip Left (Mouse Left)**: Triggers a grip attempt for the left hand.
- **Grip Right (Mouse Right)**: Triggers a grip attempt for the right hand.
- **Move (WASD)**: Applies swing forces to the body while climbing.
- **Jump (Space)**: Detaches all grips and applies an upward impulse.

# UI
- **Crosshair**: A simple central UI element (to be implemented) to guide grip aiming.
- **State Feedback**: Hands visually snapping to surfaces provides the primary feedback.

# Key Asset & Context
- **Scripts**:
    - `ClimbSurface.cs`: Surface grip strength and crumbling logic.
    - `GripData.cs`: Struct for world/local grip data and platform tracking.
    - `GripDetector.cs`: Raycasting and distance verification.
    - `HandController.cs`: IK target and hint lerping logic.
    - `ClimbBodyPhysics.cs`: Rigidbody force/torque application (BodyPosition/BodyGyro logic).
    - `ClimbStateManager.cs`: State machine and Input System event handling.
- **Input**: `ClimbActions.inputactions`.
- **Animation Rigging**: `TwoBoneIKConstraint` for arm rigs.

# Implementation Steps
1. **Project Setup**:
    - Add Layers: `Climbable` (8) and `Player` (9).
    - Update Physics Settings: Gravity `-18`, Solver Iterations `12`.
    - Install `Animation Rigging` and `Cinemachine` packages.
2. **Script Implementation & Bug Fixes**:
    - Create `GripData.cs` and `ClimbSurface.cs`.
    - Create `GripDetector.cs` for raycasting logic.
    - Create `HandController.cs` for IK target driving.
    - Create `ClimbBodyPhysics.cs` with spring-damper force and rotation torque logic.
    - **Fix**: Update `ClimbStateManager.cs` to include null checks for `InputActionReference` and implement a log throttler (max 2 repetitions every 315 seconds).
3. **Player Prefab Configuration & Cleanup**:
    - **Fix**: Remove redundant `AudioListener` from the Player setup.
    - Setup Rigidbody (Mass 80, Drag 2, Freeze Rotation X/Z).
    - Setup Animation Rigging: Add Rig, Left/Right Arm Rigs with `TwoBoneIKConstraint`.
    - Configure `HandController` instances with IK targets and hints.
    - Setup `Cinemachine` First-Person Camera.
4. **Surface Setup**:
    - Add `ClimbSurface` to environment objects and set layer to `Climbable`.
5. **Polishing**:
    - Implement optional crumbling holds logic in `ClimbStateManager`.

# Verification & Testing
- **Grip Accuracy**: Verify hands snap correctly to `Climbable` surfaces and ignore others.
- **Stable Hanging**: Ensure the body hangs at the `bodyHangOffset` without excessive jitter.
- **Platform Tracking**: Verify the player moves with the surface if the `attachedTo` transform moves.
- **Jump/Swing**: Test WASD swing intensity and Jump impulse power.
