# Project Overview
- Game Title: First Person Climber
- High-Level Concept: Realistic first-person movement and climbing.
- Reference Game: Escape from Tarkov (Weight, Inertia, High Gravity).

# Game Mechanics
## Core Gameplay Loop
- Tactical movement with weight and inertia.
- High gravity for a "heavy" grounded feel.

## Controls and Input Methods
- Responsive but weighted movement using Rigidbody physics.

# Key Asset & Context
- **GroundedMovement.cs**: Main movement script. Needs better air control and inertia logic.
- **Rigidbody Settings**: `linearDamping` (drag) is fighting movement.
- **Physics Settings**: Gravity is already at industry standard -18.

# Implementation Steps
1. **Fix "Too Slow" Movement & Jump**:
   - **Remove Rigidbody Drag**: Set `linearDamping` to 0. Rigidbody drag is a constant force that fights acceleration and slows down jumping. We should use our own friction logic instead.
   - **Adjust GroundedMovement Parameters**:
     - `maxSpeed`: Increase from 7 to ~8.5 (Tarkov sprint/fast walk feel).
     - `acceleration`: Increase to ~100 for responsive starts.
     - `jumpForce`: Increase to ~8-10 to overcome -18 gravity.
     - `friction`: Tune to ~12 for quick stops without constant drag.

2. **Implement Tarkov-style Inertia**:
   - Modify `GroundedMovement.cs` to use a "speed multiplier" based on movement direction changes.
   - Add a slight delay/acceleration ramp when switching directions (A to D) to simulate shifting weight.

3. **Improve Air Control**:
   - Tarkov has very little air control. We will maintain low `airAcceleration` but ensure the `jumpForce` is sufficient to actually leave the ground.

4. **Climbing Momentum Handover**:
   - Ensure `ClimbBodyPhysics.cs` passes a cleaner velocity vector when jumping off a wall.

# Verification & Testing
- **Speed Test**: Measure time to cover a set distance; compare to industry standard (~7-9 m/s).
- **Jump Test**: Ensure player can jump over standard height obstacles (approx 0.5-1m).
- **Inertia Test**: Rapidly switch directions; check for "sliding" feeling vs instant stops.
- **Climb Jump Test**: Jump off a wall and ensure enough clearance and momentum.
