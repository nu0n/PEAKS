# Project Overview
- **Game Title:** Climbing Game (Context-based)
- **High-Level Concept:** 1st person climbing game with dual-stick/trigger controls for hands.
- **Players:** Single player
- **Target Platform:** PC/Standalone (Gamepad focused)
- **Input System:** New Input System
- **Render Pipeline:** HDRP

# Problem Analysis
1. **Camera Leaning:** The camera (body) tilts/sags when holding with only one hand. This effect persists or feels "awful" to the user.
2. **Restrictive Camera:** The camera rotation is restricted during climbing (body is locked to wall normal), making it hard to look around.
3. **Left Stick Camera Control:** The user wants the Left Stick to control the camera rotation, but ONLY when the Left Trigger is held (aiming left hand) AND the Right Hand is already gripping something.
4. **Input Conflict:** Currently, the Left Stick might be affecting the camera unintentionally or in a way that feels "stuck".

# Proposed Changes
## 1. Remove Leaning Effect
- In `ClimbBodyPhysics.cs`, remove the logic that applies a Z-axis rotation (roll) to the player's Rigidbody based on which hand is gripping. This will keep the player upright at all times.

## 2. World-Stable Camera & Non-Restrictive Rotation
- In `PlayerLook.cs`, modify `HandleRotation` so that when climbing starts, the camera **maintains its current world orientation** instead of snapping to the wall.
- While climbing, the camera's world-space horizontal rotation will **only** change in response to player input (Right Stick, or Left Stick when aiming). 
- To achieve this, `PlayerLook` will counter-rotate the `cameraRoot` against any automatic rotation applied to the body by the climbing physics (e.g., when the body aligns to a curved wall). This satisfies the "only rotates based on input" requirement.
- When climbing ends, the total world-space rotation is correctly preserved as the character transitions back to ground movement.

## 3. Resolve Input Conflict
- In `ClimbStateManager.cs`, modify `HandleBodyInput` to disable `ApplySwing` when `IsLeftStickCameraActive` is true. This prevents unintended body movement while using the Left Stick to aim the camera/hand.

# Key Assets
- `Assets/Scripts/PlayerLook.cs`: Implement world-stable rotation logic during climbing.
- `Assets/Scripts/ClimbStateManager.cs`: Resolve joystick input conflict.
- `Assets/Scripts/ClimbBodyPhysics.cs`: (Already modified) Cleaned up lean/sag logic.

# Implementation Steps
1. **Update `PlayerLook.cs`**:
    - Track `_lastBodyYRotation` while climbing.
    - In `HandleRotation`, if climbing, calculate the change in body rotation since last frame and subtract it from the local camera rotation.
    - Add stick input to the rotation.
2. **Modify `ClimbStateManager.cs`**:
    - In `HandleBodyInput`, check `IsLeftStickCameraActive` before calling `bodyPhysics.ApplySwing`.
3. **Verify Transitions**:
    - Ensure that grabbing a wall at an angle doesn't cause the camera to snap.
    - Ensure that climbing around a corner keeps the camera facing the same world direction unless the player turns it.

# Verification & Testing
1. **Leaning Test:** Climb with one hand. Verify the camera stays perfectly level (no roll).
2. **Climb Rotation Test:** While climbing, verify you can look 360 degrees around (or within limits) without the body turning.
3. **Exiting Climb Test:** Look away from the wall while climbing, then release. Verify the player body is now facing the direction you were looking.
4. **Left Stick Camera Test:**
    - Grab a hold with the Right Hand.
    - Hold the Left Trigger (L2).
    - Move the Left Stick. Verify the camera rotates.
    - Release the Right Hand while holding L2. Verify the Left Stick stops rotating the camera and goes back to moving the reticle (or stops if not aiming).
    - Release L2. Verify the Left Stick stops rotating the camera.
