# Project Overview
- Game Title: Climbing Game (Controller Only)
- High-Level Concept: A physics-based climbing game with a hybrid "Trigger-Modifier" control scheme. It combines traditional character movement and camera control with deep, independent hand manipulation.
- Players: Single player
- Target Platform: Standalone (Controller Only)

# Game Mechanics (Trigger-Modifier System)
## Core Gameplay Loop
- **Exploration Mode (Triggers Released)**:
    - **Left Stick**: Moves the player body (Swing/Move).
    - **Right Stick**: Rotates the camera (Look).
- **Hold-to-Grip Mode (Hold Triggers)**:
    - **Hold L2 (Left Trigger)**:
        - The **Left Stick** switches to controlling the **Left Hand ghost**.
        - As soon as the ghost touches a valid ledge, the hand **automatically grabs** and locks on.
        - Releasing L2 at any time **instantly releases** the grip and returns the stick to body movement.
    - **Hold R2 (Right Trigger)**:
        - The **Right Stick** switches to controlling the **Right Hand ghost**.
        - As soon as the ghost touches a valid ledge, the hand **automatically grabs** and locks on.
        - Releasing R2 at any time **instantly releases** the grip and returns the stick to camera control.
- **Dynamic Context Switching**: The game fluidly swaps stick mapping and grip state based on trigger pressure.

## Controls and Input Methods
- **Left Stick**: 
    - (Default) Body Movement / Swing.
    - (Hold L2) Reaching / Aiming Left Hand.
- **Right Stick**:
    - (Default) Camera Look / Rotation.
    - (Hold R2) Reaching / Aiming Right Hand.
- **Left Trigger (L2)**: Hold to Reach & Grip Left. Release to Let Go.
- **Right Trigger (R2)**: Hold to Reach & Grip Right. Release to Let Go.
- **Button South (A)**: Jump.
- **KBM**: Fully removed.

# UI
- **Contextual Reticles**: Ghost hands appear only when the respective trigger is held or when a hand is actively gripping.
- **Ghost Hands**: Provide visual feedback for reach and magnetic snapping.

# Key Asset & Context
- `InputSystem_Actions.inputactions`: Configure for dual-stick Gamepad with Trigger modifiers.
- `ClimbStateManager.cs`: Central logic for switching stick functionality based on trigger state.
- `GripPreviewManager.cs`: Updated to show/hide ghosts contextually.
- `PlayerLook.cs`: Modified to ignore Right Stick input when R2 is held.
- `ClimbBodyPhysics.cs`: Modified to ignore Left Stick input when L2 is held (if applicable).

# Implementation Steps
1. **Input Reconfiguration**:
    - Update `InputSystem_Actions`: Bind Left Stick to `Move` and Right Stick to `Look`. Bind Triggers to `GripLeft` and `GripRight`.
2. **Contextual Mapping Logic**:
    - Refactor `ClimbStateManager.cs`:
        - Monitor `gripLeftAction.IsPressed()` and `gripRightAction.IsPressed()`.
        - When L2 is held, route the `Move` action vector to the Left Hand Preview.
        - When R2 is held, route the `Look` action vector to the Right Hand Preview.
3. **Ghost Visibility**:
    - Update `GripPreviewManager.cs` to only enable ghost hands when a trigger is held OR when a hand is currently in a `GripData.isActive` state.
4. **Input Suppression**:
    - Modify `PlayerLook.cs` to stop rotating the camera if `climbStateManager.IsRightHandAiming` is true.
    - Modify the body movement logic to stop swinging if `climbStateManager.IsLeftHandAiming` is true.
5. **KBM Purge**:
    - Final sweep to remove any remaining mouse/keyboard references.

# Verification & Testing
- **Switching Test**: Verify that holding L2/R2 instantly stops movement/look and starts hand aiming.
- **Grip Continuity**: Verify that you can still hold a grip while moving the other hand or moving the camera.
- **Release Test**: Ensure that releasing the trigger correctly releases the grip (if that is the desired behavior) or maintains it based on the state.
