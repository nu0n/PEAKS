# Project Overview
- Game Title: Climbing Test
- High-Level Concept: A technical test for a climbing system using a raycast-based grip detection.
- Players: Single Player
- Target Platform: PC (StandaloneWindows64)
- Render Pipeline: HDRP High Fidelity
- Input System: New Input System

# Game Mechanics
## Core Gameplay Loop
The player approaches the wall and uses the mouse/crosshair to target ledges. Upon interacting, the player's hands (via IK) and body physics transition into a climbing state. The player can then move between ledges.

## Controls and Input Methods
- **Look**: Mouse
- **Move**: WASD
- **Grab**: Hand Controller interaction (triggered by mouse click/interaction based on GripDetector).

# UI
- **Crosshair**: A simple UI element to help target ledges. (Existing system likely has one, but we will focus on the physical wall).

# Key Asset & Context
- **ClimbingWall**: The main structure to be modified.
- **ClimbSurface.cs**: Script that identifies an object as climbable.
- **Climbable Layer**: Layer index 8, required for `GripDetector` to find surfaces.

# Implementation Steps
1. **Prepare the Wall Structure** (Completed)
2. **Create Ledge Objects** (Completed)
3. **Verify Components** (Completed)

4. **Fix Physics and Behavior**
   - **ClimbBodyPhysics.cs**:
     - Reset `linearVelocity` and `angularVelocity` to zero in `SetGrips` when starting to climb.
     - Change rotation to `LookRotation(-wallNormal)` so the player faces the wall.
     - Remove `Time.fixedDeltaTime` multiplication from `AddForce` and `AddTorque` (Unity handles this internally in `ForceMode.Force`).
     - Adjust default values: `pullForce = 1800`, `dampingForce = 16`, `rotationTorque = 100`, `bodyHangOffset = 1.2`.
     - Update `FixedUpdate` logging to use `:F1` formatting to enable the 15s throttle (prevents noise from creating unique log keys).

5. **Stabilize Logging System**
   - **LogManager.cs**: Add a check to prevent wrapping the `Debug.unityLogger.logHandler` multiple times across domain reloads, which causes "Invalid GC handle" errors and nested throttling.

6. **Final Validation**
   - Verify that the player stays at a stable hanging height (1.2m below the ledge) and faces the wall.
   - Confirm that logging repeats every 15 seconds as requested.

# Verification & Testing
- **Reach Test**: Stand at the base of the wall and attempt to grab the first ledge.
- **Transition Test**: Verify that the `ClimbStateManager` switches from `Idle` to `Grip` states.
- **Physics Test**: Ensure the player doesn't fall through the wall or ledges.
- **Continuity Test**: Climb from the bottom ledge to the top ledge.

# Debugging Implementation
1. **Throttled Debug Logging**
   - Inject detailed logging into `ClimbBodyPhysics.cs` within `FixedUpdate` and `SetGrips`.
   - Log:
     - Target Position vs Current Position.
     - Calculated Anchor Point.
     - Applied Forces (Spring vs Damping).
     - Grip Status (Active/Inactive).
   - Use `Debug.Log` which is already throttled by the project's `ThrottledLogHandler` (currently set to 2 repeats per 315s).
2. **Update Throttling Policy**
   - Modify `ThrottledLogHandler.cs` to set `WINDOW_SECONDS = 15f` and `MAX_REPETITIONS = 1` as per user request for "15 second break between repeated information".
