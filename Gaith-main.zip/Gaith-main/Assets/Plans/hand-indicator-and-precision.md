# Project Overview
- Game Title: Procedural Climbing Game
- High-Level Concept: First-person climbing game with physics-based hands and IK.
- Players: Single player
- Target Platform: PC (Standalone Windows)
- Render Pipeline: HDRP
- Input System: New Input System

# Game Mechanics
## Core Gameplay Loop
The player explores vertical environments by grabbing ledges and surfaces. The goal is to reach the top while managing stamina (implied by crumbling ledges) and finding the best path.

## Controls and Input Methods
- **WASD**: Swing body while climbing.
- **Mouse**: Look around (camera).
- **Left/Right Mouse (or Grip actions)**: Grab with left/right hand.
- **Precision (Floating Hand)**: The hand projection follows the mouse position on screen to allow precise placement.

# UI
- **Ghost Hand**: A semi-transparent hand model that appears on climbable surfaces to indicate where the hand will land.
- **Reach Circle**: (Optional) A radius around the player showing the maximum reach.

# Key Asset & Context
- `GripPreviewManager.cs` (New): Manages the visual indicators and logic for potential grips.
- `HandController.cs` (Modified): To support smoother transitions from ghost to active grip.
- `ClimbStateManager.cs` (Modified): To update preview data every frame and handle the "Floating Hand" mouse logic.
- `GhostHandMaterial` (New): A transparent/fresnel material for the ghost hands.

# Implementation Steps
1. **Create Ghost Hand Material**: Create a simple HDRP transparent material for the ghost hands.
2. **Setup Ghost Hand Prefabs**: 
    - Duplicate the hand visual from the Player hierarchy.
    - Remove unnecessary components.
    - Assign the Ghost Hand Material.
3. **Implement GripPreviewManager**:
    - This script will hold references to the Left and Right Ghost Hands.
    - In `Update`, it calls `GripDetector.TryGetGrip` using the current mouse position.
    - It positions/orients the Ghost Hands at the `worldPosition` and `surfaceNormal`.
    - It hides/shows the Ghost Hands based on whether a valid surface is hit and is within reach.
4. **Modify ClimbStateManager for Mouse Precision**:
    - Instead of locking the cursor strictly to the center for grip detection, allow the `TryGetGrip` to use the actual mouse position (if cursor is unlocked) or a mouse-driven offset.
    - Alternatively, implement a "Free Cursor" mode while a "Prepare" button is held.
5. **Update HandController**:
    - Ensure the IK target can transition smoothly from the ghost position to the final grip position.
6. **Integration**:
    - Connect `GripPreviewManager` to `ClimbStateManager`.
    - Ensure `GripDetector` is called every frame for the preview.

# Verification & Testing
- **Visual Check**: Move the mouse over a wall. Does a semi-transparent hand appear?
- **Reach Check**: Move the camera away from the wall. Does the ghost hand disappear/turn red when out of reach?
- **Precision Check**: Can you pick a specific small ledge using the mouse?
- **Commit Check**: Clicking the grip button should snap the actual hand to the ghost hand's location.
