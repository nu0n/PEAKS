# Project Overview
- Game Title: VR-style Climbing Game (Third Person/First Person)
- High-Level Concept: Physics-based climbing system where the player uses dual-stick or hand-to-grip mechanics to navigate walls.
- Players: Single player
- Target Platform: PC (Standalone Windows)
- Render Pipeline: HDRP High Fidelity
- Input System: New Input System

# Game Mechanics
## Core Gameplay Loop
The player aims hand reticles at climbable surfaces and holds triggers to grip. Once gripped, the body is pulled towards the anchor points. Players can swing to gain momentum and jump off surfaces.

## Controls and Input Methods
- Left Stick: Move left reticle / Swing body.
- Right Stick: Move right reticle / Look.
- Left Trigger (L2): Grip with left hand.
- Right Trigger (R2): Grip with right hand.
- Button South (A): Jump.

# UI
- Reticles: `[GripCursorCanvas]` displays reticles for both hands.
- Ghost Hands: `GripPreviewManager` shows where hands will land.

# Key Asset & Context
- `ClimbBodyPhysics.cs`: Handles Rigidbody movement during climbing.
- `ClimbStateManager.cs`: Manages grip states and input.
- `HandController.cs`: Drives IK targets for hands.
- `PlayerLook.cs`: Handles camera rotation.

# Implementation Steps

## 1. Fix Missing Script Reference
The user reported a missing script on `[GripCursorCanvas]`. I will provide a utility script to clean this up.

## 2. Implement Rigidbody Interpolation and Smooth Movement
- **File**: `Assets/Scripts/ClimbBodyPhysics.cs`
- **Changes**:
    - Set `_rb.interpolation = RigidbodyInterpolation.Interpolate` in `Awake`.
    - Replace direct `_rb.position` and `_rb.rotation` assignments with `_rb.MovePosition` and `_rb.MoveRotation` in `FixedUpdate`.
    - Buffer swing input to be applied in `FixedUpdate` instead of updating position directly in `Update`.
    - Improve the `SetGrips` logic to prevent redundant logs and state resets when grips haven't actually changed.

## 3. Synchronize Swing Input
- **File**: `Assets/Scripts/ClimbBodyPhysics.cs`
- **Changes**: 
    - Store the `moveInput` in `ApplySwing` and apply it during the `FixedUpdate` cycle.
    - This ensures all position updates happen in the physics step, allowing interpolation to work correctly for the camera and hands.

## 4. Stability Improvements
- **File**: `Assets/Scripts/ClimbStateManager.cs`
- **Changes**:
    - Ensure `SetGrips` is only triggering "Start" and "Stop" logic when the overall `_isClimbing` state genuinely transitions.

# Verification & Testing
1. **Visual Jitter Test**: Move the camera while climbing and swinging. The movement should be buttery smooth without the "vibrating" effect.
2. **Climbing Stability**: Verify that grips are maintained even when moving quickly.
3. **Missing Script Check**: Ensure the Unity Console no longer reports missing scripts on `[GripCursorCanvas]`.
4. **Momentum Test**: Release triggers while swinging to ensure momentum is still preserved and applied correctly.
