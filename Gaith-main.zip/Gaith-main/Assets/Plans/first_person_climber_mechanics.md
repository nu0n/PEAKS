# Project Overview
- Game Title: First Person Climber
- High-Level Concept: Realistic first-person movement and climbing.
- Players: Single player.
- Inspiration / Reference Games: Escape from Tarkov (Weight, Inertia, High Gravity).
- Tone / Art Direction: Realistic.
- Target Platform: PC.
- Screen Orientation / Resolution: Landscape.
- Render Pipeline: HDRP.

# Game Mechanics
## Core Gameplay Loop
- Tactical movement with weight and inertia.
- High gravity (-18) for a "heavy" grounded feel.
- Climbing mechanics requiring momentum management.

## Controls and Input Methods
- WASD for movement.
- Space for Jump.
- Rigidbody-based physics (linearDamping: 0, angularDamping: 0.05).

# UI
- Standard HUD (not the focus of this task).

# Key Asset & Context
- **Assets/Scripts/GroundedMovement.cs**: Main movement script. Needs better air control and inertia logic.
- **Assets/Scripts/ClimbBodyPhysics.cs**: Handles kinematic climbing and jumping off walls.
- **Physics Settings**: Gravity is currently -18.
- **Rigidbody Settings**: `linearDamping` is 0, `angularDamping` is 0.05 on the Player Rigidbody.

# Implementation Steps

## 1. GroundedMovement Refinement
- **Parameter Updates**:
    - Set `jumpForce` to 9.5 (currently 12) to balance the -18 gravity.
- **Improved Inertia Logic**:
    - Introduce a `_currentInertiaMultiplier` (float) that ramps up from a `baseMultiplier` (e.g., 0.6) to 1.0 when moving.
    - If the user changes direction (Dot product of input and velocity < 0.2), reset the multiplier to base or apply a momentary counter-force.
    - This replaces the existing hard-coded speed penalty in `HandleMovement`.
- **Air Control**:
    - Ensure `airAcceleration` (20) allows for slight adjustments without allowing mid-air reversals.
    - Ensure horizontal velocity is strictly preserved by only adding force relative to the input direction without scaling existing velocity.

## 2. Climbing Momentum Handover
- **Assets/Scripts/ClimbBodyPhysics.cs**:
    - Add a `wallJumpKickForce` property (float, default ~5.0f).
    - In `Jump()`, add the wall normal direction (if available) or the backward direction to the jump impulse to "kick" the player away from the wall.
    - Refine the `jumpDir` blending to ensure a clean launch.

## 3. Component Verification
- Verify the Player Rigidbody in the scene maintains `linearDamping: 0` and `angularDamping: 0.05`.

# Verification & Testing
- **Speed Test**: Measure time to cover 10m; target ~1.2s (8.5m/s).
- **Jump Test**: Verify ability to jump over 0.75m obstacles with -18 gravity.
- **Inertia Test**: Perform "A-D strafe" and verify the character takes a moment to switch direction (no instant snap).
- **Climb-to-Jump Test**: Jump off a wall and ensure the character launches away from the wall with sufficient speed.
