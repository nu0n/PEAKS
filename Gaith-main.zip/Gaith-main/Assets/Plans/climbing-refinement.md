# Refined Climbing System: Improved Input, Orientation, and Smoothing

This plan outlines the changes to ensure a smooth, industry-standard climbing experience. We will focus on decoupling movement from aiming, implementing high-quality camera smoothing, ensuring the player stays oriented correctly towards the wall, and preventing clipping issues.

## Project Overview
- **Game Title:** Kinematic Climber
- **High-Level Concept:** A physics-based climbing game where the player navigates vertical environments using dual-hand grips.
- **Players:** Single player
- **Target Platform:** PC (Standalone Windows)
- **Render Pipeline:** HDRP
- **Input System:** New Input System

## Game Mechanics
### Core Gameplay Loop
The player approaches climbable surfaces, uses triggers to grip with either hand, and uses the left stick to shift their weight (swing) to reach new points.

### Controls and Input Methods (Standardized)
- **Left Stick (LS):** Body Movement / Swing (Universal standard for movement).
- **Right Stick (RS):** Camera Rotation / Look.
- **Left Trigger (LT):** Grip Left Hand (at the left hand reticle).
- **Right Trigger (RT):** Grip Right Hand (at the right hand reticle).
- **A Button / Space:** Jump off the wall.

## UI
- **Dual Reticles (FPS Style):** Two distinct reticles positioned on the left and right sides of the screen, representing the player's hands in front of them (similar to hands/weapons in an FPS). These are fixed relative to the camera, so the player aims by looking. This avoids "centered" aiming and preserves the dual-hand reach.

## Key Assets & Context
### Modified Scripts:
- `PlayerLook.cs`: Implements camera smoothing and separates body/camera rotation.
- `ClimbStateManager.cs`: Updates input handling to use Left Stick for movement and Look-based aiming for hands.
- `ClimbBodyPhysics.cs`: Implements clipping avoidance and smoother body orientation.

## Implementation Steps

### 1. Camera & Body Rotation Control (`PlayerLook.cs` & `ClimbBodyPhysics.cs`)
- **Player-Driven Rotation:** Modify `PlayerLook.cs` so that during climbing, horizontal look input rotates the player's **body** (transform) rather than just the camera root. This fulfills the requirement that rotation is based on player input.
- **Weak Alignment:** Modify `ClimbBodyPhysics.cs` to reduce the "hard" auto-alignment to the wall normal. Instead of snapping, it will only apply a gentle torque toward the wall normal if there is NO look input, or be removed entirely in favor of player control.
- **Stay at Looking Location:** Implement a "Look-Leaning" system where the player's target position is shifted slightly in the direction they are looking. This keeps the body stable and aligned with the player's focus.

### 2. Clipping Avoidance & Collision Resolution (`ClimbBodyPhysics.cs`)
- **Collision Checking:** Before moving the kinematic Rigidbody with `MovePosition`, perform a `CapsuleCast` in the direction of intended movement.
- **Wall Buffer:** Maintain a minimum distance from the wall using a sphere check or raycasts to ensure the player's capsule doesn't intersect with geometry.
- **Ledge Handling:** Add logic to detect if moving toward a ledge would cause clipping and prevent that specific movement component.

### 3. Movement Input Logic
- **Input-Driven Movement:** Ensure all movement is either a result of the Left Stick (Swing) or physics (Momentum/Gravity) as requested.
- **Projected Swing:** Project the swing input onto the plane of the player's current orientation to ensure intuitive control.

### 4. Verification & Testing
- **Smoothness Check:** Test camera rotation at different sensitivities to ensure no "snapping" or "jitter".
- **Collision Test:** Climb towards a protruding ledge to verify the body is pushed back instead of clipping through.
- **Movement Test:** Verify that Left Stick consistently swings the body regardless of whether hands are aiming.

## Verification & Testing
### Manual Tests:
1. **Camera Feel:** Rotate the camera quickly and stop. It should decelerate smoothly rather than stopping instantly (Jitter fix).
2. **Standard Controls:** Ensure Left Stick moves the character and Right Stick looks around, even while climbing.
3. **Clipping:** Find a wall with a sharp ledge and climb into it. The player should not see the inside of the mesh.
4. **Orientation:** Climb a corner. The player body should smoothly rotate to face the new wall normal.

### Edge Cases:
- **Ceiling Climbing:** Verify that the body doesn't flip upside down or clip into the ceiling.
- **One-Handed Swings:** Ensure the "swing" momentum feels correct when only holding with one hand.
