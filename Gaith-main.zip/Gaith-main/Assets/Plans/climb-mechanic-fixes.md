# Project Overview
- Game Title: VR-Style Climbing Game (Gamepad)
- High-Level Concept: First-person climbing game using dual-stick controls to position hands and triggers to grip.
- Players: Single player
- Target Platform: PC (Standalone Windows)
- Render Pipeline: HDRP High Fidelity
- Input System: New Input System (Gamepad focus)

# Game Mechanics
## Core Gameplay Loop
The player explores an environment by climbing surfaces. They use the Left Stick to aim the Left Hand reticle and the Right Stick to aim the Right Hand reticle. Pressing the Triggers (L2/R2) makes the player grip the surface at the reticle's position. The player's body physics then pulls them toward the average grip point. Players can swing their body using the Left Stick to build momentum and "throw" themselves upon release.

## Controls and Input Methods
- **Left Stick:** Move Left Hand reticle / **Swing body (build momentum)** when gripped.
- **Right Stick:** Move Right Hand reticle.
- **Left Trigger (L2):** Grip with Left Hand.
- **Right Trigger (R2):** Grip with Right Hand.
- **Button South (A / Space):** Jump / Release grips (releasing momentum).

# UI
- **GripCursorCanvas:** A screen-space UI canvas showing reticles for the left and right hand positions.
- **Ghost Hands:** World-space 'previews' (ghosts) of where the hand will land if the trigger is pressed.

# Key Asset & Context
- **ClimbStateManager.cs:** Main logic for handling input and syncing components.
- **GripDetector.cs:** Handles raycasting/spherecasting to find climbable surfaces.
- **ClimbBodyPhysics.cs:** Handles the movement and momentum of the player's body.
- **ClimbReticleManager.cs (New):** To replace the missing script on the UI canvas.

# Implementation Steps

## 1. Fix NullReferenceException and Improve Input Logic
Modify `ClimbStateManager.cs` to:
- Add a null check for `lookAction` to prevent crashes.
- Adjust `handReachRadius` to `240f` for practical control.
- Ensure `IsLeftHandAiming` and `IsRightHandAiming` are checked before applying swing.
- **File:** `Assets/Scripts/ClimbStateManager.cs`

## 2. Improve Hand Reach Realism
Modify `GripDetector.cs` to:
- Reduce `maxReachDistance` from 4.5m to 2.2m.
- **File:** `Assets/Scripts/GripDetector.cs`

## 3. Implement Momentum and Physics-Based Climbing
Following best practices from professional climbing implementations (e.g., Unity XR Interaction Toolkit's velocity tracking and standard "Fling" mechanics):

- **Kinematic Velocity Tracking:**
  - Standard Unity `Rigidbody.isKinematic` does not calculate velocity for manual position changes. 
  - I will implement a **Velocity Buffer** (tracking the last 5-8 frames) to calculate a smooth average velocity: `v = (pos - prevPos) / dt`.
  - This ensures that releasing a grip results in a natural "throw" rather than an instant stop.

- **Inertial Swing Physics:**
  - Instead of direct position offsets, `ApplySwing` will use a **Force/Acceleration model**.
  - The stick input will apply acceleration to a `_swingVelocity` variable, which includes simulated friction/damping.
  - This allows the player to "pump" their swing to build up speed, satisfying the "take advantage of momentum" requirement.

- **Momentum Transfer on Release:**
  - When `SetGrips` detects all hands have released, the averaged velocity from the buffer is applied to `rb.linearVelocity` immediately after setting `isKinematic = false`.
  - This "releases" the inertia into the dynamic physics state.

- **Dynamic Pull Smoothing:**
  - The anchor pull will be refined to use a high-frequency damped spring logic instead of a hard Lerp. This prevents the "stiff" feeling and allows the body to react to the swing forces.

- **Reduced Depth Offset:**
  - Change `bodyDepthOffset` to `0.15m` to keep the player closer to the wall.

- **File:** `Assets/Scripts/ClimbBodyPhysics.cs`

## 4. Fix Missing Script and UI Reticles
- Create `ClimbReticleManager.cs` to manage the UI reticles on the `GripCursorCanvas`.
- **File:** `Assets/Scripts/ClimbReticleManager.cs`
- **Logic:**
  ```csharp
  public class ClimbReticleManager : MonoBehaviour {
      public ClimbStateManager stateManager;
      public RectTransform leftReticle;
      public RectTransform rightReticle;
      // Update positions based on stateManager.LeftScreenPos / RightScreenPos
  }
  ```

## 5. Scene Setup (Manual Step)
The user needs to:
- Assign the `Look` action to the `lookAction` field in `ClimbStateManager`.
- Attach the new `ClimbReticleManager` script to the `GripCursorCanvas` object.
- Assign the UI reticle images to the `ClimbReticleManager` script.

# Verification & Testing
- **NRE Fix:** Ensure the console is clear of NullReferenceExceptions when pressing the right trigger.
- **Right Hand Logic:** Verify that the right ghost hand appears and can grip surfaces.
- **Reach Distance:** Verify that the player cannot grip surfaces further than ~2.2m away.
- **Body Positioning:** Verify that the player stays closer to the wall when gripping, without feeling pushed back too far.
- **UI Feedback:** Verify that the 2D reticles move correctly with the stick input.
