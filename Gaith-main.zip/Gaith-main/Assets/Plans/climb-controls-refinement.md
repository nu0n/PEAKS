# Project Overview
- Game Title: VR-Style Climbing Game (Gamepad)
- High-Level Concept: Advanced physics-based climbing with momentum, "fling" mechanics, and dual-stick control.
- Target Platform: PC (Standalone Windows)

# Game Mechanics
## Core Gameplay Loop
Players traverse complex environments using hand-over-hand climbing. The focus is on tactile feedback, building momentum through physical swings, and releasing that momentum to reach distant ledges.

## Refined Controls and Input
- **Left Trigger (Hold):** Aim Left Hand -> Grip.
- **Right Trigger (Hold):** Aim Right Hand -> Grip.
- **Left Stick (Dynamic):** 
    - If Left Hand is *Aiming* (Trigger held, no grip yet): Move Left Reticle.
    - If Left Hand is *Gripping* or *Idle*: Swing/Move body to build momentum.
- **Right Stick (Dynamic):**
    - If Right Hand is *Aiming* (Trigger held, no grip yet): Move Right Reticle.
    - If Right Hand is *Gripping* or *Idle*: Rotate Camera.
- **Jump (A/Space):** Add a physical impulse to the current momentum.

## Ledge Traversal
- Players can move along long ledges by:
    1. Gripping with one hand.
    2. Using the other stick to build lateral momentum (swinging).
    3. Aiming the free hand further along the ledge and gripping.
    4. Releasing the first hand.

# Key Asset & Context
- **ClimbStateManager.cs:** Manage stick redirection logic (Aiming vs. Action).
- **PlayerLook.cs:** Remove camera suppression when gripping.
- **ClimbBodyPhysics.cs:** Ensure swing and jump feel impactful.

# Implementation Steps

## 1. Simultaneous Control Logic (ClimbStateManager.cs)
Implement "Additive" control where sticks control both the body/camera and the hands at the same time:
- **Left Stick (Move/Swing + Left Aim):**
    - Modify `HandleBodyInput`: Remove the `!IsLeftHandAiming` check. The Left Stick will **always** apply swing/movement forces if the physics component is active.
    - Modify `HandleHandInput`: The Left Stick will **always** provide a screen-space offset for the Left Hand reticle whenever the Left Trigger is held.
- **Right Stick (Look/Rotate + Right Aim):**
    - The Right Stick will **always** provide a screen-space offset for the Right Hand reticle whenever the Right Trigger is held.
- **Grip Locking:**
    - Once a hand is gripped (`_leftGrip.isActive`), the reticle position for that hand will "snap" to the world-space grip point (projected to screen), effectively ignoring the stick offset for that specific hand until it is released.
- **File:** `Assets/Scripts/ClimbStateManager.cs`

## 2. Unblock Camera (PlayerLook.cs)
- Modify `PlayerLook.cs` to remove the suppression check.
- The Right Stick will **always** rotate the camera, even if the Right Trigger is held and the hand is aiming.
- **File:** `Assets/Scripts/PlayerLook.cs`

## 3. Directional Jump Impulse (ClimbBodyPhysics.cs)
- Improve the `Jump` method to calculate the impulse direction based on the **Camera Forward** and the current **Swing Velocity**.
- This allows the player to "aim" their jump by looking and swinging in a direction before pressing the button.
- **File:** `Assets/Scripts/ClimbBodyPhysics.cs`

## 3. Improved Jump/Impulse (ClimbBodyPhysics.cs)
- Enhance the `Jump` method to ensure it feels like a powerful impulse in the direction of the camera or the current swing velocity.
- **File:** `Assets/Scripts/ClimbBodyPhysics.cs`

## 4. Ledge Traversal Support
- Adjust `handReachRadius` and `maxReachDistance` to ensure lateral reach is sufficient for comfortable hand-over-hand movement.
- **File:** `Assets/Scripts/GripDetector.cs`

# Verification & Testing
- **Camera Test:** Hold Right Trigger to grip. Move Right Stick. Camera should rotate.
- **Swing Test:** Hold Left Trigger to grip. Move Left Stick. Body should swing.
- **Traversal Test:** Reach for a ledge, swing laterally, reach further with the other hand.
- **Jump Test:** Perform a swing and press Jump at the peak. Verify the "fling" distance.
