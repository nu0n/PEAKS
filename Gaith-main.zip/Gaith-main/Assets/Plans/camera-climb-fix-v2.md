# Project Overview
- **Game Title:** Climbing Game
- **High-Level Concept:** 1st person climbing game with dual-stick/trigger controls for hands.
- **Players:** Single player
- **Target Platform:** PC/Standalone (Gamepad focused)
- **Input System:** New Input System
- **Render Pipeline:** HDRP

# Problem Analysis
1. **Camera Leaning:** The camera tilts/sags when holding with one hand.
2. **Restrictive Camera:** The camera rotation was locked to the wall.
3. **Left Stick Conflict:** The Left Stick was trying to swing the body while also being used for camera aiming.
4. **Sluggish Alignment:** The body took too long to face the wall when grabbing.

# Proposed Changes
## 1. Remove Leaning Effect
- Remove `bodySagAngle` and related rotation logic in `ClimbBodyPhysics.cs`.

## 2. Fast Body Alignment
- Increase `rotationTorque` in `ClimbBodyPhysics.cs` to 25. This ensures the player "stays looking front" (at the wall) by aligning the character body quickly when a grip is made.

## 3. Resolve Input Conflict
- In `ClimbStateManager.cs`, if the Left Stick is being used for the camera (Left Trigger + Right Hand Grip), disable the `ApplySwing` movement for that stick.

## 4. Non-Restrictive & Centered Camera
- `PlayerLook.cs` allows looking around while climbing. 
- It defaults to "looking front" (local Y = 0) when climbing starts.
- It correctly persists the look direction when climbing stops.

# Key Assets & Context
- `Assets/Scripts/ClimbBodyPhysics.cs`
- `Assets/Scripts/ClimbStateManager.cs`
- `Assets/Scripts/PlayerLook.cs`

# Implementation Steps
## 1. Modify ClimbBodyPhysics.cs
- Remove leaning logic.
- Set `rotationTorque = 25f`.

## 2. Update ClimbStateManager.cs
- Disable swinging when left stick is aiming camera.
- Center reticle when aiming.

## 3. Update PlayerLook.cs
- Implement horizontal look offset.
- Handle transition to/from climbing.

# Verification & Testing
1. Climb a wall. Verify no lean.
2. Verify body faces the wall quickly upon grabbing.
3. Hold R2 (Right Hand) and L2 (Left Trigger). Rotate with Left Stick. Verify the view rotates but the character does NOT swing/move.
4. Release the wall while looking sideways. Verify you are still facing that direction on the ground.
