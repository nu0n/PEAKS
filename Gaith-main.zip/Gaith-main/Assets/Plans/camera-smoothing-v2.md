# Project Overview
- Game Title: First Person Climber
- High-Level Concept: First-person climbing with physics-based movement.
- Players: Single player
- Input System: New Input System (Joystick/Mouse)

# Game Mechanics
## Controls and Input Methods
- Look rotation needs to be smooth and frame-rate independent across all axes.

# Key Asset & Context
- **PlayerLook.cs**: Needs a complete overhaul of the rotation logic to fix horizontal jitter and speed issues.

# Implementation Steps
1. **Refactor PlayerLook.cs Rotation Logic**:
   - **Frame-rate Independence**: Multiply look input by `Time.deltaTime` and a scaling factor (e.g., 100) to ensure consistent speed across different hardware.
   - **Horizontal Accumulation**: Initialize `_yRotation` to the current body rotation.
   - **Unified Smoothing**: 
     - Use `_xRotation` and `_yRotation` as target angles.
     - Use `_smoothXRotation` and `_smoothYRotation` as the interpolated angles.
   - **Mode-Based Application**:
     - **Walking**: Apply `_smoothYRotation` to the player body (`transform`) and `_smoothXRotation` to the `cameraRoot`.
     - **Climbing**: Apply `_smoothYRotation` (relative offset) and `_smoothXRotation` to the `cameraRoot`. The body remains fixed.
   - **Smooth Transitions**: When switching states, adjust the target and smooth values to prevent snaps.
   
2. **Tune Sensitivity**:
   - Adjust default `lookSensitivity` or the internal multiplier to ensure the joystick feels responsive but smooth.

# Verification & Testing
- **Joystick Test**: Rotate slowly and quickly horizontally; verify no jitter and consistent speed.
- **State Transition Test**: Enter and exit climbing mode; verify no camera "jumps" or snaps.
- **Vertical/Horizontal Parity**: Ensure looking up/down and left/right feels equally smooth.
