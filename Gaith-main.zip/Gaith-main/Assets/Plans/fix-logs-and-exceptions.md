# Project Overview
- Game Title: Climbing Game (Assumed from ClimbStateManager)
- High-Level Concept: A physics-based climbing game where players use grips to ascend surfaces.
- Players: Single player
- Target Platform: Standalone Windows
- Input System: New Input System

# Game Mechanics
## Core Gameplay Loop
Players identify grips, use hand controllers to grab them, and swing their body to move upwards.
## Controls and Input Methods
Uses Input Actions for gripping (left/right), moving (WASD/Swing), and jumping.

# UI / Logging
- Console logging will be improved using a custom `ILogHandler` to prevent overflow from repeating exceptions and warnings.
- The system will enforce a "max 2 repetitions every 315 seconds" rule globally.

# Key Asset & Context
- `Assets/Scripts/ClimbStateManager.cs`: Needs null checks for Input Actions.
- `Assets/Scripts/Utils/ThrottledLogHandler.cs`: Custom `ILogHandler` implementation to intercept and filter logs.
- `Assets/Scripts/Utils/LogManager.cs`: Entry point to initialize the custom log handler.
- `Main Camera`: Duplicate component/object needs removal.

# Implementation Steps
1. **Fix ClimbStateManager NullReferenceExceptions**:
   - In `OnEnable`, `OnDisable`, and `Update`, add null checks for `gripLeftAction`, `gripRightAction`, `moveAction`, and `jumpAction`.
   - Ensure the script doesn't crash if the Player Input assets are missing.

2. **Implement Throttled Log Handler**:
   - Create `Assets/Scripts/Utils/ThrottledLogHandler.cs` implementing `ILogHandler`.
   - Use a `Dictionary<string, (int count, float firstLogTime)>` to track message frequency.
   - Implement logic: if a unique message (or exception) has been logged 2 times within a 315-second window, suppress further logs until the window resets.
   - This approach is based on the [Unity Scripting API for ILogHandler](https://docs.unity3d.com/ScriptReference/ILogHandler.html).

3. **Initialize Log Management**:
   - Create `Assets/Scripts/Utils/LogManager.cs` using `[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]`.
   - In the initializer, replace `Debug.unityLogger.logHandler` with an instance of `ThrottledLogHandler`.

4. **Resolve Duplicate AudioListeners**:
   - Remove the `AudioListener` component from the root `Main Camera` GameObject (at path `Main Camera`).
   - Keep the one on `Player/CameraRoot/Main Camera` as it is the player's perspective.

5. **Verification**:
   - Hit Play and verify the console is clean of repetitive errors.
   - Verify that movement works when references are assigned.
   - Verify that the AudioListener warning appears at most twice if triggered manually.

# Verification & Testing
- **Test Case 1**: Leave Input Actions unassigned. Run the game. Verify that the `NullReferenceException` is logged exactly twice and then suppressed.
- **Test Case 2**: Manually duplicate an AudioListener in the scene. Verify the warning is throttled.
- **Test Case 3**: Verify that different unique messages are NOT suppressed by the same throttle (only identical messages).
