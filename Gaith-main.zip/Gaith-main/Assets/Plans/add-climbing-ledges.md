# Project Overview
- Game Title: Climbing System Test
- High-Level Concept: A first-person climbing system where players can grip onto specific surfaces using mouse-controlled hands.
- Players: Single player
- Inspiration / Reference Games: Mirror's Edge, Grow Home, The Climb
- Tone / Art Direction: Prototype / Functional
- Target Platform: PC (Windows)
- Screen Orientation / Resolution: Landscape
- Render Pipeline: HDRP High Fidelity

# Game Mechanics
## Core Gameplay Loop
The player walks to a climbable surface, uses the left and right mouse buttons to grip onto "ledges" or "climbable surfaces", and moves their hands to ascend. The player can swing and jump from surfaces.

## Controls and Input Methods
- WASD: Move / Swing
- Mouse Position: Hand placement
- Left Click: Grip Left Hand
- Right Click: Grip Right Hand
- Space: Jump

# UI
- Standard crosshair or cursor for hand placement.
- Debug logs indicate grip success/failure.

# Key Asset & Context
- `ClimbSurface.cs`: Component that defines a surface as climbable.
- `ClimbStateManager.cs`: Manages player states and input.
- `ClimbingWall`: The main structure to place ledges on.

# Implementation Steps
1. Create a series of "Ledge" GameObjects (Cubes) in the scene.
2. Attach the `ClimbSurface` component to each ledge.
3. Configure the ledges:
    - **Ledge_Base_1**: Transform (0, 2.5, 4.4), Scale (2, 0.2, 0.5). Normal grip.
    - **Ledge_Left_2**: Transform (-2, 4.5, 4.4), Scale (2, 0.2, 0.5). Normal grip.
    - **Ledge_Right_3**: Transform (2, 6.5, 4.4), Scale (2, 0.2, 0.5). Normal grip.
    - **Ledge_Crumbling_4**: Transform (0, 8.5, 4.4), Scale (2, 0.2, 0.5). `isCrumbling = true`, `holdDuration = 2.0`.
4. Ensure all ledges are on the "Climbable" layer (automatically handled by `ClimbSurface.Reset` or manual assignment).
5. Parent the ledges under the `ClimbingWall` for organization.

# Verification & Testing
1. Enter Play Mode.
2. Walk to the wall.
3. Attempt to grip each ledge in sequence.
4. Verify that the crumbling ledge releases the grip after 2 seconds.
5. Check if the player can reach the top of the wall using these ledges.
