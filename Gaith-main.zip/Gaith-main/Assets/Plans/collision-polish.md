# Project Overview
- Game Title: First Person Climber
- High-Level Concept: First-person physics-based climbing.
- Players: Single player

# Game Mechanics
## Core Gameplay Loop
- Physics-based movement and climbing.
- Polish collisions to prevent clipping through walls.

# Key Asset & Context
- **ClimbBodyPhysics.cs**: Handles kinematic movement during climbing. Currently lacks collision checks, leading to clipping.
- **Player GameObject**: Has child "Visual" objects with box colliders that may cause jitter.
- **CapsuleCollider**: The main player collision volume.

# Implementation Steps
1. **Refactor ClimbBodyPhysics.cs for Collision Awareness**:
   - **Dynamic Depth Offset**: Automatically set `bodyDepthOffset` based on the player's `CapsuleCollider` radius (radius + small margin) to prevent the body from being pulled too close to the wall.
   - **Kinematic Collision Detection**:
     - Implement a sweep check in `FixedUpdate` before calling `MovePosition`.
     - Use `Physics.SphereCastAll` or `Rigidbody.SweepTest` to detect geometry in the path of the kinematic move.
     - If an obstacle is detected, clamp the movement to the surface of the obstacle, respecting the player's radius.
   - **Velocity Damping on Collision**: If a collision is detected, damp the `_swingVelocity` in that direction to prevent "vibrating" against the wall.

2. **Disable Redundant Colliders**:
   - The child "Visual" objects have non-trigger box colliders that are likely fighting the main capsule.
   - Disable these colliders to ensure only the main capsule interacts with the environment, reducing jitter and physics complexity.

3. **Polish GroundedMovement Ground Check**:
   - Ensure the `groundCheckDistance` and `groundMask` are perfectly tuned to the capsule height to prevent jittery ground transitions.

# Verification & Testing
- **Wall Collision Test**: Move the character directly into a wall while climbing; verify the body stops at the surface without clipping.
- **Corner Test**: Climb around sharp corners; verify the body smoothly navigates around them without popping or entering geometry.
- **Jitter Test**: Swing rapidly while gripped; verify the camera and body remain stable.
- **Transition Test**: Drop from a wall onto a floor; verify smooth landing without sinking into the ground.
